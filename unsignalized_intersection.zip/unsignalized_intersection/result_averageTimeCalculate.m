stateNum=length(vehicleState);
startTime=0;
endTime=0;
TimeList=[0,0,0];
for i=1:stateNum
    thisState=vehicleState{i};
    if isempty(thisState)==0
        vehicleNum=length(thisState(:,1));
        for j=1:vehicleNum
            vehicleID=thisState(j,1);
            if ismember(vehicleID,TimeList(:,1))==1
                [~,temp]=ismember(vehicleID,TimeList(:,1));
                if thisState(j,6)<9.5
                    TimeList(temp,3)=1;
                end
                if TimeList(temp,3)==0
                    TimeList(temp,2)=TimeList(temp,2)+0.1;
                end
            else
                TimeList=[TimeList;vehicleID,0.1,0];
            end
        end
    end
    
end

result1=[];
for i=1:length(TimeList(:,1))
    if TimeList(i,3)==1
        result1=[result1;TimeList(i,2)];
    end
end

averageTime=mean(result1(max(length(result1)-99,1):length(result1)))
averageTime=mean(result1(100:(length(result1)-100)))