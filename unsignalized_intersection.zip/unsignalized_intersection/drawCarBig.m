function [draw] = drawCarBig(Car,CarColor)

CarLength=8;
CarX=Car(1);
CarY=Car(2);
CarDir=Car(3);

CarHeadX=CarX+CarLength*sind(CarDir);
CarHeadY=CarY+CarLength*cosd(CarDir);


plot([CarHeadX,CarX],[CarHeadY,CarY],'Color',CarColor,'LineWidth',6)


% plot(CarX,CarY,'.','Color','r','MarkerSize',10)


% plot([CarHeadX,CarX],[CarHeadY,CarY],'LineWidth',5)
hold on
% plot(CarX,CarY,'.','Color','b','MarkerSize',35)
hold on
% plot(CarHeadX,CarHeadY,'.','Color','r','MarkerSize',20)
hold on

draw=1;
end

