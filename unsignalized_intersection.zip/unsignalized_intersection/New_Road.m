function New_Road()
load('Parameter.mat','Load_length','Load_length2','nodPath','simulation_folder');
%% Headings
delete(nodPath);
fid=fopen(nodPath,'w+');
fprintf(fid,'%s\r\n','<?xml version="1.0" encoding="UTF-8"?>');
fprintf(fid,'%s\r\n','<nodes>');
fprintf(fid,'%s\r\n','   <node id="Center" x="0.0" y="0.0" type="traffic_light"/>');

fprintf(fid,'%s%d%s\r\n','   <node id="West" x="-',Load_length,'.0" y="0.0" type="junction"/>');
fprintf(fid,'%s%d%s\r\n','   <node id="East" x="+',Load_length,'.0" y="0.0" type="junction"/>');
fprintf(fid,'%s%d%s\r\n','   <node id="South" x="0.0" y="-',Load_length,'.0" type="junction"/>');
fprintf(fid,'%s%d%s\r\n','   <node id="North" x="0.0" y="+',Load_length,'.0" type="junction"/>');

% fprintf(fid,'%s%d%s\r\n','   <node id="West2" x="-',Load_length2,'.0" y="0.0" type="priority"/>');
% fprintf(fid,'%s%d%s\r\n','   <node id="East2" x="+',Load_length2,'.0" y="0.0" type="priority"/>');
% fprintf(fid,'%s%d%s\r\n','   <node id="South2" x="0.0" y="-',Load_length2,'.0" type="priority"/>');
% fprintf(fid,'%s%d%s\r\n','   <node id="North2" x="0.0" y="+',Load_length2,'.0" type="priority"/>');

fprintf(fid,'%s\r\n','</nodes>');
fclose(fid);
currentfolder = pwd;
cd (simulation_folder);
[~,~]=dos('net.bat');
cd (currentfolder);
end