constraints=[];


bestLength=99999999;

vehicleNum=length(vehicles(:,1));
constraintTree=[{1},{[]},0];
constraintTree=[{[]},{1},0];
constraintTree=[];
%{[],[],1}�����ڵ�Լ����������Լ�����Ƿ��Ѿ���ִ�й�
%0��û����飬1���ڱ���飬2�Ѿ���鲢���ӹ�

nodeConstraints=[3,1,3,1];
nodeConstraints=[];
%x,y,���裬�����
edgeConstraints=[3,1,2,0,0,1,1];
edgeConstraints=[];
%x,y,���裬����x������y���������裬�����

if isempty(constraintTree)==0
    constraintTreeNum=length(constraintTree(:,1));
else
    constraintTreeNum=0;
end

tryNum=0;
tic

treeCheckNum=1;
treeFindNum=1;

answer=[];


while(1)
    tryNum=tryNum+1;
    if mod(tryNum,100)==0
        tryNum
    end
    clf
    tic
    nodeConstraintsIter=[];
    edgeConstraintsIter=[];
    
    if isempty(constraintTree)==0
        constraintTreeNum=length(constraintTree(:,1));
    else
        constraintTreeNum=0;
    end
    
%     for i=1:constraintTreeNum
%         if i<constraintTreeNum
%             for j=max(i+1,treeCheckNum):constraintTreeNum
%                 treeCheckNum=max(i+1,treeCheckNum);
%                 if constraintTree{j,3}==0
%                     treeNodeI=constraintTree{i,1};
%                     treeNodeJ=constraintTree{j,1};
%                     treeEdgeI=constraintTree{i,2};
%                     treeEdgeJ=constraintTree{j,2};
%                     
%                     result = sameConstraintCheck(treeNodeI,treeNodeJ,treeEdgeI,treeEdgeJ);
%                     
%                     if result==1
%                         constraintTree{j,3}=3;%�ظ��ĳ�ͻ
%                     end
%                     
%                 end
%             end
%         end
%     end
    
    for i=treeCheckNum:constraintTreeNum
        for j=1:constraintTreeNum
            if constraintTree{i,3}==0 && i~=j
                treeNodeI=constraintTree{i,1};
                treeNodeJ=constraintTree{j,1};
                
                treeEdgeI=constraintTree{i,2};
                treeEdgeJ=constraintTree{j,2};
                
                result = sameConstraintCheck(treeNodeI,treeNodeJ,treeEdgeI,treeEdgeJ);
                
                if result==1
                    constraintTree{i,3}=3;%�ظ��ĳ�ͻ
                end
                
            end
        end
    end
    treeCheckNum=constraintTreeNum+1;
    
    toc1=toc;
    tic
    constraintChoose=0;
    for i=treeFindNum:constraintTreeNum
        treeFindNum=i;
        
        if constraintTree{i,3}==0 && constraintTree{i,4}>=bestLength
            constraintTree{i,3}=4;
            
        elseif constraintTree{i,3}==0 && constraintTree{i,4}<bestLength
            %��ʼ��չ�˽ڵ�
            constraintChoose=i;
            constraintTree{i,3}=1;
            
            if isempty(constraintTree{i,1})==0
                nodeConstraintChoose=constraintTree{i,1};
                nodeConstraintNum=length(nodeConstraintChoose(:,1));
                
                
                
            else
                nodeConstraintNum=0;
            end
            for j=1:nodeConstraintNum
                nodeConstraintsIter=[nodeConstraintsIter;nodeConstraints(nodeConstraintChoose(j,1),:)];
            end
            
            
            if isempty(constraintTree{i,2})==0
                edgeConstraintChoose=constraintTree{i,2};
                edgeConstraintNum=length(edgeConstraintChoose(:,1));
            else
                edgeConstraintNum=0;
            end
            for j=1:edgeConstraintNum
                edgeConstraintsIter=[edgeConstraintsIter;edgeConstraints(edgeConstraintChoose(j,1),:)];
            end
            
            break
        end
    end
    toc2=toc;
    tic
    if constraintTreeNum~=0 && constraintChoose==0
        toc
        if isempty(answer)==1
            answer={0,0,0,0,0,-1};
        end
        disp('12312312312312312312312312312')
        break
    end
    
    nodeConstraintsIter;
    edgeConstraintsIter;
    
    [paths,ccc,lengthCount] = planningWithConstarints(vehicles,targets,nodeConstraintsIter,edgeConstraintsIter);
%     thisPaths=[paths{1,1},paths{2,1},paths{3,1},paths{4,1},paths{5,1}]
%         draw3DPath(paths,nodeConstraintsIter,edgeConstraintsIter)
    
    %     aaa=paths{1,1};
    %     aaa=paths{2,1};
    toc3=toc;
    tic;
    if constraintChoose~=0
        constraintTree{constraintChoose,4}=lengthCount;
    end
    
    [nodeConstraints,edgeConstraints,constraintTree,conflictFlag] = conflictCheck(paths,nodeConstraints,edgeConstraints,constraintTree,assignSort);
    %     disp('222')
%     if constraintTreeNum>3850
%         
%         if constraintTree{3850,3}~=0
%             draw3DPath(paths,nodeConstraintsIter,edgeConstraintsIter)
%             pause(0.001)
%         end
%     end
    toc4=toc;
    tic
    if conflictFlag==0 && constraintChoose~=0
        constraintTree{constraintChoose,5}=1;
        if lengthCount<bestLength
            bestLength=lengthCount;
            answer={paths,nodeConstraintsIter,edgeConstraintsIter,constraintTree,constraintChoose,bestLength};
%             draw3DPath(paths,nodeConstraintsIter,edgeConstraintsIter)
            pause(0.001)
        end
    end
    
    if conflictFlag==0 && constraintTreeNum==0 && tryNum~=1
        if lengthCount<bestLength
            bestLength=lengthCount;
            answer={paths,nodeConstraintsIter,edgeConstraintsIter,constraintTree,constraintChoose,bestLength};
%             draw3DPath(paths,nodeConstraintsIter,edgeConstraintsIter)
            pause(0.001)
        end
    end
    
    if constraintTreeNum==0 && tryNum~=1
        answer={paths,nodeConstraintsIter,edgeConstraintsIter,constraintTree,constraintChoose,bestLength};
%         draw3DPath(paths,nodeConstraintsIter,edgeConstraintsIter)
        pause(0.001)
        toc
        break
    end
    
    
    %     pause(0.1)
    %     disp('#######################################################################')
%     if conflictFlag==0
%         if constraintChoose~=0
%             constraintTree{constraintChoose,5}=1;
%             bestLength=lengthCount;
%         end
%         pause(0.1)
%         tryNum
%         
%         draw3DPath(paths,nodeConstraintsIter,edgeConstraintsIter)
%         break
%     end


    if tryNum>10000
        if isempty(answer)==1
            answer={0,0,0,0,0,-1};
        else
            
        end
        
        return
    end

    toc5=toc;
    ttt=[toc1,toc2,toc3,toc4,toc5];
    
    if isempty(answer)==0
        break
    end
end

% draw3DPath(answer{1},answer{2},answer{3})