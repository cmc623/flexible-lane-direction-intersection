function[C,D,G,E,u,v]=assignz(C,D,G,E,u,v)%��Ƕ�����Ԫ��
while any(u)
    row=find(u==1,1);
    while row
        col=find(C(row,:)==1);
        D(row)=col;
        G(col)=row;
        E(row,col)=0;
        u=u-C(:,col);
        v(col)=0;
        C(:,col)=0;
        row=find(u==1,1);
    end
    col=find(v==1,1);
    while col
        row=find(C(:,col)==1,1);
        D(row)=col;
        G(col)=row;
        E(row,col)=0;
        v=v-C(row,:);
        u(row)=0;
        C(row,:)=0;
        col=find(v==1,1);
    end
    if any(u)
        row=find(u,1);
        col=find(C(row,:),1);
        D(row)=col;
        G(col)=row;
        E(row,col)=0;
        u=u-C(:,col);
        u(row)=0;
        v=v-C(row,:);
        v(col)=0;
        C(:,col)=0;
        C(row,:)=0;
    else return;
    end
end