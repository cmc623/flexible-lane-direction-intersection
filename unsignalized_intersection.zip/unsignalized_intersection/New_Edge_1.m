function New_Edge()
load('Parameter.mat','Load_length','Load_length2','edgePath','simulation_folder');
%% Headings
delete(edgePath);
fid=fopen(edgePath,'w+');
fprintf(fid,'%s\r\n','<?xml version="1.0" encoding="UTF-8"?>');

fprintf(fid,'%s\r\n','<edges>');

fprintf(fid,'%s\r\n','   <edge id="West_in" from="West" to="Center" priority="78" numLanes="3" speed="20"/>');
fprintf(fid,'%s\r\n','   <edge id="West_out" from="Center" to="West" priority="78" numLanes="3" speed="20"/>');

fprintf(fid,'%s\r\n','   <edge id="East_in" from="East" to="Center" priority="78" numLanes="3" speed="20"/>');
fprintf(fid,'%s\r\n','   <edge id="East_out" from="Center" to="East" priority="78" numLanes="3" speed="20"/>');

fprintf(fid,'%s\r\n','   <edge id="South_in" from="South" to="Center" priority="78" numLanes="3" speed="20"/>');
fprintf(fid,'%s\r\n','   <edge id="South_out" from="Center" to="South" priority="78" numLanes="3" speed="20"/>');

fprintf(fid,'%s\r\n','   <edge id="North_in" from="North" to="Center" priority="78" numLanes="3" speed="20"/>');
fprintf(fid,'%s\r\n','   <edge id="North_out" from="Center" to="North" priority="78" numLanes="3" speed="20"/>');


fprintf(fid,'%s\r\n','</edges>');

fclose(fid);
currentfolder = pwd;
cd (simulation_folder);
[~,~]=dos('net.bat');
cd (currentfolder);
end