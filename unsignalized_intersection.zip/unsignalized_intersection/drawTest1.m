function drawTest1(Vehicle_Position_List,goal_Positions)
clf
num=length(Vehicle_Position_List(:,1));
num2=length(goal_Positions(:,1));


for i=1:num
    
    scatter(Vehicle_Position_List(i,1),Vehicle_Position_List(i,2),50,'r');
    hold on
    scatter(goal_Positions(i,1),goal_Positions(i,2),100,'b');
    hold on
    
end

end