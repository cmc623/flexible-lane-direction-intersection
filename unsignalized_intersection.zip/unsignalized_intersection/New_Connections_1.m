function New_Connections()
load('Parameter.mat','Load_length','connPath','simulation_folder');
%% Headings
delete(connPath);
fid=fopen(connPath,'w+');
fprintf(fid,'%s\r\n','<?xml version="1.0" encoding="UTF-8"?>');

fprintf(fid,'%s\r\n','<connections>');

fprintf(fid,'%s\r\n','   <connection from="West_in" to="North_out" fromLane="2" toLane="2"/>');
fprintf(fid,'%s\r\n','   <connection from="West_in" to="East_out" fromLane="1" toLane="1"/>');
fprintf(fid,'%s\r\n','   <connection from="West_in" to="South_out" fromLane="0" toLane="0"/>');

fprintf(fid,'%s\r\n','   <connection from="South_in" to="West_out" fromLane="2" toLane="2"/>');
fprintf(fid,'%s\r\n','   <connection from="South_in" to="North_out" fromLane="1" toLane="1"/>');
fprintf(fid,'%s\r\n','   <connection from="South_in" to="East_out" fromLane="0" toLane="0"/>');

fprintf(fid,'%s\r\n','   <connection from="East_in" to="South_out" fromLane="2" toLane="2"/>');
fprintf(fid,'%s\r\n','   <connection from="East_in" to="West_out" fromLane="1" toLane="1"/>');
fprintf(fid,'%s\r\n','   <connection from="East_in" to="North_out" fromLane="0" toLane="0"/>');

fprintf(fid,'%s\r\n','   <connection from="North_in" to="East_out" fromLane="2" toLane="2"/>');
fprintf(fid,'%s\r\n','   <connection from="North_in" to="South_out" fromLane="1" toLane="1"/>');
fprintf(fid,'%s\r\n','   <connection from="North_in" to="West_out" fromLane="0" toLane="0"/>');

fprintf(fid,'%s\r\n','</connections>');

fclose(fid);
currentfolder = pwd;
cd (simulation_folder);
[~,~]=dos('net.bat');
cd (currentfolder);
end