function output = BrysonDenhamEvents(input)

phaseTimes=size(input.phase,2);

for i=1:phaseTimes
    x3f{i} = input.phase(i).finalstate(3);
    
    x1f{i} = input.phase(i).finalstate(1);
    x2f{i} = input.phase(i).finalstate(2);
    x3f{i} = input.phase(i).finalstate(3);
    t0f{i} = input.phase(i).initialtime;
    tff{i} = input.phase(i).finaltime;
    
    x1i{i} = input.phase(i).initialstate(1);
    x2i{i} = input.phase(i).initialstate(2);
    x3i{i} = input.phase(i).initialstate(3);
    t0i{i} = input.phase(i).initialtime;
    tfi{i} = input.phase(i).finaltime;
end
% x3f
output.objective = x3f{1};
for i=2:phaseTimes
    output.objective =output.objective+x3f{i};
end

for i=2:phaseTimes
    output.eventgroup(i-1).event = [x2i{i}-x2f{i-1}];
end