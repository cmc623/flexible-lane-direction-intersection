function [draw] = drawHungary(Agent,Goal)
draw=0;
[Distance]=getDistance(Agent,Goal);
[f,D,G]=assign(Distance)
num=length(D);
for i=1:num
plot([Agent(i,1),Goal(D(i),1)],[Agent(i,2),Goal(D(i),2)])
hold on
plot(Agent(i,1),Agent(i,2),'.','Color','b','MarkerSize',50); 
hold on
plot(Goal(D(i),1),Goal(D(i),2),'.','Color','r','MarkerSize',50); 
hold on
end

set(gca,'XminorGrid','on');
set(gca,'YminorGrid','on');axis equal
hold off
draw=1;
end

