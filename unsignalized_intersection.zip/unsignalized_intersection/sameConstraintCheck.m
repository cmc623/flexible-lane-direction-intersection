function result = sameConstraintCheck(treeNodeI,treeNodeJ,treeEdgeI,treeEdgeJ)

result=0;

if isempty(treeNodeI)==0
    treeNodeINum=length(treeNodeI);
else
    treeNodeINum=0;
end

if isempty(treeNodeJ)==0
    treeNodeJNum=length(treeNodeJ);
else
    treeNodeJNum=0;
end

if isempty(treeEdgeI)==0
    treeEdgeINum=length(treeEdgeI);
else
    treeEdgeINum=0;
end

if isempty(treeEdgeJ)==0
    treeEdgeJNum=length(treeEdgeJ);
else
    treeEdgeJNum=0;
end


if treeNodeINum==treeNodeJNum && treeEdgeINum==treeEdgeJNum
    
    nodeDifferent=0;
    edgeDifferent=0;
    
    for i=1:treeNodeINum
        if ismember(treeNodeI(i),treeNodeJ)==0
            nodeDifferent=1;
            break
        end
    end
    
    for i=1:treeEdgeINum
        if ismember(treeEdgeI(i),treeEdgeJ)==0
            edgeDifferent=1;
            break
        end
    end
    
    if nodeDifferent==0 && edgeDifferent==0
        result=1;
    end
end


end

