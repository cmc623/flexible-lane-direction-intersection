function [pointList,curve]=PointOnBezier(draw,num,P)

pointList=[];
curve=[];
n=length(P)-1;

for tt=0:num
    t=tt/num;
    x=0;y=0;
    dxdt=0;dydt=0;
    dx2dt2=0;dy2dt2=0;
    for j=0:n
        temp=nchoosek(n,j)*(1-t)^(n-j)*t^j;
        x=x+P(j+1,1)*temp;
        y=y+P(j+1,2)*temp;
        
        d1=nchoosek(n,j)*((j-n)*(1-t)^(n-j-1)*t^j+j*(1-t)^(n-j)*t^(j-1));
        dxdt=dxdt+P(j+1,1)*d1;
        dydt=dydt+P(j+1,2)*d1;
        
        d2=nchoosek(n,j)*((n-j)*(n-j-1)*(1-t)^(n-j-2)*t^j+j*(j-n)*(1-t)^(n-j-1)*t^(j-1)...
            +j*(j-n)*(1-t)^(n-j-1)*t^(j-1)+j*(j-1)*(1-t)^(n-j)*t^(j-2));
        dx2dt2=dx2dt2+P(j+1,1)*d2;
        dy2dt2=dy2dt2+P(j+1,2)*d2;
        
        c=(dxdt*dy2dt2-dydt*dx2dt2)/((dxdt^2+dydt^2)^1.5);
        
    end
    if tt==0 || tt==num
        c=0;
    end
    pointList=[pointList;x,y];
    curve=[curve c];
end
% subplot(2,1,1)
if draw==1
    if n==3
        plot(pointList(:,1),pointList(:,2),'b')
    else
        plot(pointList(:,1),pointList(:,2),'b','LineWidth',0.8)
    end
    hold on
    axis equal
end
% subplot(2,1,2)
% plot(1:num+1,curve)

end