armLength=400;
drawLength=70;
laneWidth=3.3;

stateNum=length(vehicleState);
for i=350:5:stateNum
    clf
    hold on
    i
    vehicleStateTemp=vehicleState{i};
    if isempty(vehicleStateTemp)==0
        vehicleNum=length(vehicleStateTemp(:,1));
        for j=1:vehicleNum
            vehicleX=vehicleStateTemp(j,2);
            vehicleY=vehicleStateTemp(j,3);
            vehicleTheta=vehicleStateTemp(j,4);
            vehicleSpeed=vehicleStateTemp(j,5);
            
            if vehicleX>armLength-drawLength && vehicleX<armLength+drawLength && vehicleY>armLength-drawLength && vehicleY<armLength+drawLength
                notFlag=0;
                temp=500;
                if vehicleX>armLength+temp && vehicleY<armLength
                    notFlag=1;
                end
                if vehicleY>armLength+temp && vehicleX>armLength
                    notFlag=1;
                end
                if vehicleY<armLength-temp && vehicleX<armLength
                    notFlag=1;
                end
                if vehicleX<armLength-temp && vehicleY>armLength
                    notFlag=1;
                end
                
                if notFlag==0 && vehicleSpeed>0
                    
                    switch vehicleStateTemp(j,10)
                        case 0
                            vehicleColor=[1,0.8,0.8];
                        case 1
                            vehicleColor=[0.8,1,0.8];
                        case 2
                            vehicleColor=[0.8,0.8,1];
                    end
                    
                    temp=15;
                    if abs(vehicleX-armLength)<temp && abs(vehicleY-armLength)<temp
                        for k=i:min(i+40,stateNum)
                            vehicleStateTemp2=vehicleState{k};
                            if isempty(vehicleStateTemp2)==0
                                vehicleNum11=length(vehicleStateTemp2(:,1));
                                for m=1:vehicleNum11
                                    if vehicleStateTemp2(m,1)==vehicleStateTemp(j,1)
                                        vehicleX2=vehicleStateTemp2(m,2);
                                        vehicleY2=vehicleStateTemp2(m,3);
                                        vehicleTheta2=vehicleStateTemp2(m,4);
                                        temp=15;
                                        if abs(vehicleX2-armLength)<temp && abs(vehicleY2-armLength)<temp
                                            plot([vehicleX2,vehicleX2-4*sind(vehicleTheta2)],[vehicleY2,vehicleY2-4*cosd(vehicleTheta2)],'Color',vehicleColor,'LineWidth',4)
                                        end
                                        break
                                    end
                                end
                            end
                        end
                    end
                    
                    
                end
            end
            
        end
        
        for j=1:vehicleNum
            vehicleX=vehicleStateTemp(j,2);
            vehicleY=vehicleStateTemp(j,3);
            vehicleTheta=vehicleStateTemp(j,4);
            
            if vehicleX>armLength-drawLength && vehicleX<armLength+drawLength && vehicleY>armLength-drawLength && vehicleY<armLength+drawLength
                notFlag=0;
                temp=500;
                if vehicleX>armLength+temp && vehicleY<armLength
                    notFlag=1;
                end
                if vehicleY>armLength+temp && vehicleX>armLength
                    notFlag=1;
                end
                if vehicleY<armLength-temp && vehicleX<armLength
                    notFlag=1;
                end
                if vehicleX<armLength-temp && vehicleY>armLength
                    notFlag=1;
                end
                
                if notFlag==0
                    
                    
                    switch vehicleStateTemp(j,10)
                        case 0
                            vehicleColor='r';
                        case 1
                            vehicleColor='g';
                        case 2
                            vehicleColor='b';
                    end
                    
                    plot([vehicleX,vehicleX-4*sind(vehicleTheta)],[vehicleY,vehicleY-4*cosd(vehicleTheta)],'Color',vehicleColor,'LineWidth',4)
                end
            end
            
        end
        
        
    end
    axis equal
    axis([armLength-drawLength armLength+drawLength armLength-drawLength armLength+drawLength])
    grid minor
    
    temp=12;
    plot([0,armLength-temp],[armLength,armLength],'Color','k','LineWidth',1)
    plot([0,armLength-temp],[armLength-laneWidth,armLength-laneWidth],'--','Color','k','LineWidth',1)
    plot([0,armLength-temp],[armLength-laneWidth*2,armLength-laneWidth*2],'--','Color','k','LineWidth',1)
    plot([0,armLength-temp],[armLength-laneWidth*3,armLength-laneWidth*3],'Color','k','LineWidth',1)
    plot([0,armLength-temp],[armLength+laneWidth*3,armLength+laneWidth*3],'Color','k','LineWidth',1)
    
    plot([armLength*2,armLength+temp],[armLength,armLength],'Color','k','LineWidth',1)
    plot([armLength*2,armLength+temp],[armLength+laneWidth,armLength+laneWidth],'--','Color','k','LineWidth',1)
    plot([armLength*2,armLength+temp],[armLength+laneWidth*2,armLength+laneWidth*2],'--','Color','k','LineWidth',1)
    plot([armLength*2,armLength+temp],[armLength+laneWidth*3,armLength+laneWidth*3],'Color','k','LineWidth',1)
    plot([armLength*2,armLength+temp],[armLength-laneWidth*3,armLength-laneWidth*3],'Color','k','LineWidth',1)
    
    plot([armLength+laneWidth*0,armLength+laneWidth*0],[0,armLength-temp],'Color','k','LineWidth',1)
    plot([armLength+laneWidth*1,armLength+laneWidth*1],[0,armLength-temp],'--','Color','k','LineWidth',1)
    plot([armLength+laneWidth*2,armLength+laneWidth*2],[0,armLength-temp],'--','Color','k','LineWidth',1)
    plot([armLength+laneWidth*3,armLength+laneWidth*3],[0,armLength-temp],'Color','k','LineWidth',1)
    plot([armLength-laneWidth*3,armLength-laneWidth*3],[0,armLength-temp],'Color','k','LineWidth',1)
    
    plot([armLength-laneWidth*0,armLength-laneWidth*0],[armLength*2,armLength+temp],'Color','k','LineWidth',1)
    plot([armLength-laneWidth*1,armLength-laneWidth*1],[armLength*2,armLength+temp],'--','Color','k','LineWidth',1)
    plot([armLength-laneWidth*2,armLength-laneWidth*2],[armLength*2,armLength+temp],'--','Color','k','LineWidth',1)
    plot([armLength-laneWidth*3,armLength-laneWidth*3],[armLength*2,armLength+temp],'Color','k','LineWidth',1)
    plot([armLength+laneWidth*3,armLength+laneWidth*3],[armLength*2,armLength+temp],'Color','k','LineWidth',1)
    
    plot([armLength-temp,armLength-laneWidth*3],[armLength+laneWidth*3,armLength+temp],'Color','k','LineWidth',1)
    plot([armLength-temp,armLength-laneWidth*3],[armLength-laneWidth*3,armLength-temp],'Color','k','LineWidth',1)
    plot([armLength+laneWidth*3,armLength+temp],[armLength-temp,armLength-laneWidth*3],'Color','k','LineWidth',1)
    plot([armLength+laneWidth*3,armLength+temp],[armLength+temp,armLength+laneWidth*3],'Color','k','LineWidth',1)
    
    pause(0.01)
%     f=getframe(gcf);
%     str0=['videoTest\'];
%     str1=num2str(i);
%     str2=['.jpg'];
%     save_path=[str0,str1,str2];
%     print('-dpng','-r300',save_path);
end