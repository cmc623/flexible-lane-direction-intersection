function [mapNew,flag1] = layerCalculate(vehicles,conflictMap,vehicleList,layerModeNum,IDs)

layerMode1=[0,1,2;0,1,2;0,1,2];
layerMode2=[0;1;2];

if layerModeNum==1
    layerMode=layerMode1;
elseif layerModeNum==2
    layerMode=layerMode2;
end

feasibleSet=[];

IDmatrix=zeros(length(IDs),2);

for i=1:length(IDs)
    IDmatrix(i,1)=vehicles(i);
    IDmatrix(i,2)=IDs(i);
end
IDmatrix=sortrows(IDmatrix,2);


vehicleNum=length(vehicles);

map=zeros(vehicleNum,2);
flag1=0;

while(1)
    
    
    
    conflictFlag=0;
    
    okFlag=1;
    
    for i=1:vehicleNum
        turning=vehicleList(IDmatrix(i,1),10);
        if turning==0%��ת�������ж�
            if ismember(map(i,1),layerMode(1,:))==0
                okFlag=0;
                break
            end
        elseif turning==1%ֱ�п������ж�
            if ismember(map(i,1),layerMode(2,:))==0
                okFlag=0;
                break
            end
            
        elseif turning==2%��ת�������ж�
            if ismember(map(i,1),layerMode(3,:))==0
                okFlag=0;
                break
            end
            
        end
    end
    
    
    if okFlag==1
        for i=1:vehicleNum-1
            for j=i+1:vehicleNum
                i;
                j;
                vehicleList;
                map;
                trafficFlow1=vehicleList(IDmatrix(i,1),7)*9+vehicleList(IDmatrix(i,1),10)*3+map(i,1)+1;
                trafficFlow2=vehicleList(IDmatrix(j,1),7)*9+vehicleList(IDmatrix(j,1),10)*3+map(j,1)+1;
                map(i,2)=trafficFlow1;
                map(j,2)=trafficFlow2;
                conflictMap(trafficFlow1,trafficFlow2);
                if conflictMap(trafficFlow1,trafficFlow2)==1
                    conflictFlag=1;
                else
                    [i,trafficFlow1,j,trafficFlow2,conflictMap(trafficFlow1,trafficFlow2)];
                end
                if conflictFlag==1
                    break
                end
            end
            if conflictFlag==1
                break
            end
        end
    end
    
    if conflictFlag==0 && okFlag==1
        flag1=1;
        feasibleSet=[feasibleSet;map(:,1)'];
    else
        map(1,1)=map(1,1)+1;
        for i=1:vehicleNum-1
            if map(i,1)==3
                map(i,1)=0;
                map(i+1,1)=map(i+1,1)+1;
            end
        end
    end
    
    if map(vehicleNum,1)==3
        break
    end
    
    breakFlag=0;
    if isempty(feasibleSet)==0
        if  length(feasibleSet(:,1))>1000
            breakFlag=1;
        end
    end
    
    if breakFlag==1
        break
    end
    
end

selfLaneSet=zeros(1,vehicleNum);
for i=1:vehicleNum
    selfLaneSet(i)=vehicleList(IDmatrix(i,1),7);
end

if isempty(feasibleSet)==0
    setNum=length(feasibleSet(:,1));
    miniError=realmax;
    bestSolution=0;
    for i=1:setNum
        thisError=sum((feasibleSet(i,:)-selfLaneSet).^2);
        if thisError<miniError
            bestSolution=i;
        end
    end
    bestSolutionNew=feasibleSet(bestSolution,:);
    map=[bestSolutionNew',bestSolutionNew'];
end


mapNew=map;
for i=1:vehicleNum
    for j=1:vehicleNum
        if vehicles(i)==IDmatrix(j,1)
            mapNew(i,:)=map(j,:);
        end
    end
end

end

