
% rng('shuffle');



conflictMap=[
    1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 0 0 0 0 0 0
    0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0  0 0 0 0 0 0 1 1 0  0 0 0 0 0 0 0 0 0
    0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0  0 0 0 0 0 0 1 1 1  0 0 0 0 0 0 0 0 0
    0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0  0 0 0 0 0 0 1 1 1  1 1 1 1 1 1 1 1 1
    0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0  0 0 0 0 0 0 1 1 1  0 1 1 1 1 1 1 1 1
    0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1  0 0 0 0 0 0 1 1 1  0 0 1 1 1 1 1 1 1
    0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1  1 1 1 1 1 1 1 1 1  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1  0 1 1 1 1 1 1 1 1  0 0 0 0 1 1 1 1 1
    0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1  0 0 1 1 1 1 1 1 0  0 0 0 0 0 1 1 1 1
    
    0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0  0 0 0 0 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0  0 0 0 0 0 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1  1 1 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1  0 1 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1  0 0 1 1 1 1 1 1 0
    
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1
    
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1
    ];

conflictMapNum=length(conflictMap(1,:));
for i=1:conflictMapNum
    for j=i+1:conflictMapNum
        conflictMap(j,i)=conflictMap(i,j);
    end
end



global Acc_Speed_Count
global Count_all
Count_all=[0,0,0,0,1];
for tflow_i = 1:length(Tflow)
    disp('Multi');
    tflow_i
    Last_Error={'aaa',1};
    %% Output defination
    % CAV_List:
    % Col_1         Col_2       Col_3           Col_4       Col_5
    % Vehicle_ID    Status      Control_Step    solution    Control_Time
    % Col_6             Col_7                   Col_8
    % Control_Speed     Pass_vehicle    Time_to_Trafficlight
    % Col_9                 Col_10
    % Target_Green_Start
    
    % Data_record
    % Col_1         Col_2           Col_3               Col_4           Col_5
    % vehicle_ID    vehicle_Type    Vehicle_Position    Vehicle_Speed   Fuel_Consumotion
    
    %% Path
    simulation_step = 0.1;
    
    simulation_folder = 'traci_tls\data_1';
    scenarioPath = fullfile(simulation_folder,'cross.sumocfg');
    routePath = fullfile(simulation_folder,'cross.rou.xml');
    nodPath = fullfile(simulation_folder,'cross.nod.xml');
    edgePath = fullfile(simulation_folder,'cross.edg.xml');
    connPath = fullfile(simulation_folder,'cross.con.xml');
    sumoHome = getenv('SUMO_HOME');
    
    %% Flags
    SUMO_GUI = 'true';
    
    %% Parameters
    Penetration_Rate = 0.9;
    Total_Simulation_Vehicle = 300;
    Test_Speed = 10;
    Test_Platoon_Size = 9;
    
    % Vehicle_Per_Hour = 800;
    % Test_Depart_Gap = 1./(Vehicle_Per_Hour / 3600);
    % Test_Depart_Gap = floor(Test_Depart_Gap * 10)/10;
    
    Test_Depart_Gap = 5.1;
    
    % Depart_Gap = 5; %s
    intersection_offset = 8.55;
    RegularPlatoonSize = 10;
    Min_Gap = 2;
    Reaction_Time = 1;
    Vehicle_length = 4;
    Max_speed = 14.66;
    Simulation_Total_Time = 0;
    Min_acc = -6;
    Max_acc = 3;
    
    Load_length = 400;
    Load_length2 = 600;
    
    
    Ring1=15;
    Ring2=300;
    Ring3=300;%����
    Ring4=500;
    Ring5=700;
    Ring6=950;
    
    vehicle_Gap=30;%�����ڵĸ������
    
    All_Intersection_direction = {'E_L','E_F','E_R','S_L','S_F','S_R','W_L','W_F','W_R','N_L','N_F','N_R'};%F��ʾforward
    All_Leg = {'W','S','E','N'};
    All_Direction = {'L','F','R'};
    
    Vehicle_List1={};
    Vehicle_List2={};
    Vehicle_List3={};
    Vehicle_List4={};
    
    Vehicle_List=cell(1,4);
    All_Vehicle_List={};
    
    All_Route=cell(4,3);
    
    All_Route(1,1)={['West','_in_','North','_out']};
    All_Route(1,2)={['West','_in_','East','_out']};
    All_Route(1,3)={['West','_in_','South','_out']};
    
    All_Route(2,1)={['South','_in_','West','_out']};
    All_Route(2,2)={['South','_in_','North','_out']};
    All_Route(2,3)={['South','_in_','East','_out']};
    
    All_Route(3,1)={['East','_in_','South','_out']};
    All_Route(3,2)={['East','_in_','West','_out']};
    All_Route(3,3)={['East','_in_','North','_out']};
    
    All_Route(4,1)={['North','_in_','East','_out']};
    All_Route(4,2)={['North','_in_','South','_out']};
    All_Route(4,3)={['North','_in_','West','_out']};
    
    save Parameter.mat
    tic
    New_Connections_1();
    New_Road();
    New_Edge_1();
    New_Vehicle_1();
    
    
    vehicleNum=4;
    
    speedCount={'aaa',0,0};
    roadGap=30;
    
    accCount={'aaa',0,0,0,0};
    vehicleYES=0;
    
    vehicleGroupsLayer={};
    
    
    Acc_Speed_Count={'aaa',1,1,1,1,1,1};
    
    global X1 X2 X3 vF T laneWidth dt gap
    X1=0;
    X2=1000;
    X3=1200;
    vF=10;
    T=4;
    laneWidth=3.3;
    dt=simulation_step;
    gap=17;
    
    vehicleGenerateCount=0;
    
    vehicleSpeedList=cell(1,4);
    vehicleChangeLaneList=cell(1,4);
    deleteSet=[];
    
    vehicleState={};
    vehicleList1=[121212];
    
    %% GUI SET COMMANDS
    
    for Simulation_Depart_Gap = 1:length(Test_Depart_Gap)
        Depart_Gap = Test_Depart_Gap(Simulation_Depart_Gap);
        ArriveTimePlan = [];
        save('Variables.mat','ArriveTimePlan')
        save Parameter.mat
        
        switch SUMO_GUI
            case 'true'
                %                 traci.start(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --start' ' --quit-on-end']);
                %                 system(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --lanechange.duration 1' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                system(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --lanechange.duration 2' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                traci.init();
                traci.gui.setSchema('View #0','real world');
            case 'false'
                %                 traci.start(['sumo-gui ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --start' ' --quit-on-end']);
                system(['sumo -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                traci.init();
            otherwise
                continue;
        end
        
        %% Main
        
        step=0;
        
        
        
        while step <((1/simulation_step)*1000000000)
            if step==0
                vehicleList=[];
                vehicleIDList={};
            end
            
            step = step + 1;
            str12=num2str(step);
            %%%disp(str12);
            traci.simulationStep();
            %             disp('1121212121212121221')
            %             traci.trafficlights.setRedYellowGreenState('Center','OOOOOOOOOOOOOOOOOOOOO');
            %             disp('###################')
            
            
            if rand(1)<Tflow(tflow_i) && vehicleGenerateCount<testVehicleNum%�����³�
                vehicleGenerateCount=vehicleGenerateCount+1;
                temp1=rand(1);
                lane=floor(temp1*3);
                
                temp2=rand(1);
                if temp2<turningRatio(1)
                    temp2=1;
                elseif temp2<turningRatio(2)
                    temp2=2;
                else
                    temp2=3;
                end
                
                goal=All_Direction{temp2};
                
                vehicleYES=1;
                
                temp3=rand(1);
                fromDir=floor(temp3*4)+1;
                if fromDir==5
                    fromDir=4;
                end
                
                
                newVehicleID = [All_Leg{fromDir},'_',goal,'_',num2str(step)];
                
                newVehicleID=num2str(step);
                
                newVehicleRoute=All_Route{fromDir,ceil(temp2)};
                
                if goal=='L'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,3-temp2,'CAV_L');
                elseif goal=='F'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,3-temp2,'CAV_F');
                elseif goal=='R'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,3-temp2,'CAV_R');
                end
                traci.vehicle.setSpeedMode(newVehicleID,31);
                traci.vehicle.setLaneChangeMode(newVehicleID,1621);
                
                All_Vehicle_List=[All_Vehicle_List,newVehicleID];
                
                
            end
            
            
            
            
            
            
            vehicleListNew=[];
            vehicleIDListTemp = traci.vehicle.getIDList();
            vehicleIDList={};
            if isempty(vehicleIDListTemp)==0
                for i=1:length(vehicleIDListTemp)
                    vehicleIDList=[vehicleIDList,vehicleIDListTemp{i}];
                end
            end
            if isempty(vehicleIDList)==0
                vehicleIDListNum=length(vehicleIDList);
                vehicleListNew=zeros(vehicleIDListNum,20);
                
                for i=1:vehicleIDListNum
                    vehicleListNew(i,1)=str2double(vehicleIDList{i});
                    Vehicle_ID=vehicleIDList{i};
                    Temp = traci.vehicle.getPosition(Vehicle_ID);
                    vehicleListNew(i,2)=Temp(1);
                    vehicleListNew(i,3)=Temp(2);
                    vehicleListNew(i,4)=traci.vehicle.getAngle(Vehicle_ID);
                    vehicleListNew(i,5)=traci.vehicle.getSpeed(Vehicle_ID);
                    vehicleListNew(i,6)=max(abs(Load_length-Temp(1)),abs(Load_length-Temp(2)));
                    vehRoute = traci.vehicle.getRoute(Vehicle_ID);
                    fromDir=vehRoute{1};
                    toDir=vehRoute{2};
                    switch fromDir(1)
                        case 'N'
                            vehicleListNew(i,7)=0;
                        case 'E'
                            vehicleListNew(i,7)=1;
                        case 'S'
                            vehicleListNew(i,7)=2;
                        case 'W'
                            vehicleListNew(i,7)=3;
                    end
                    switch toDir(1)
                        case 'N'
                            vehicleListNew(i,8)=0;
                        case 'E'
                            vehicleListNew(i,8)=1;
                        case 'S'
                            vehicleListNew(i,8)=2;
                        case 'W'
                            vehicleListNew(i,8)=3;
                    end
                    
                    vehicleListNew(i,9) = traci.vehicle.getLaneIndex(Vehicle_ID);
                    vehTypeID = traci.vehicle.getTypeID(Vehicle_ID);
                    switch vehTypeID(5)
                        case 'L'
                            vehicleListNew(i,10)=2;
                        case 'F'
                            vehicleListNew(i,10)=1;
                        case 'R'
                            vehicleListNew(i,10)=0;
                    end
                    vehicleListNew;%1ID,2x,3y,4angle,5speed,6distance,7from,8to,9self lane,10turn,11self layer,12goal layer,13goal lane
                    
                    if vehicleListNew(i,6)<200
                        traci.vehicle.setLaneChangeMode(Vehicle_ID,0);
                        traci.vehicle.changeLane(num2str(vehicleListNew(i,1)),vehicleListNew(i,10),2);
                    end
                    
                    if vehicleListNew(i,6)<50 && vehicleListNew(i,5)>10
                        traci.vehicle.setSpeed(Vehicle_ID,10);
                    end
                    
                    if vehicleListNew(i,6)<9
                        traci.vehicle.setSpeedMode(Vehicle_ID,0);
                    end
                    
                    deleteTemp=9;
                    if Load_length-deleteTemp<vehicleListNew(i,2) && vehicleListNew(i,2)<Load_length+deleteTemp && Load_length-deleteTemp<vehicleListNew(i,3) && vehicleListNew(i,3)<Load_length+deleteTemp
                        deleteSet=[deleteSet,vehicleListNew(i,1)];
                    end
                    
                end
                
                vehicleListNew=sortrows(vehicleListNew,1);
            end
            
            vehicleState=[vehicleState,{vehicleListNew}];
            
            
            vehicleIDListTemp = traci.vehicle.getIDList();
            vehicleIDList={};
            if isempty(vehicleIDListTemp)==0
                for i=1:length(vehicleIDListTemp)
                    if ismember(str2num(vehicleIDListTemp{i}),deleteSet)==0
                        vehicleIDList=[vehicleIDList,vehicleIDListTemp{i}];
                    end
                end
            end
            if vehicleGenerateCount>0 && isempty(vehicleIDList)==1 && step>T*10*3
                vehicleIDList
                break
            end
            
            
            
            
            
            %             pause(0.1)
        end
        save([num2str(layerModeNum),'_Result_',num2str(suijishu),'_',num2str(liuliang),'_',num2str(bili),'.mat'],'vehicleState')

        
        
        traci.close()
        
        
        
    end
end
