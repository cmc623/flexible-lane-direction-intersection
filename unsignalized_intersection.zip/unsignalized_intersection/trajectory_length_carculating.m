function s=trajectory_length_carculating(pointList)

N=length(pointList(:,1));
s=0;

for j=1:N-1
    distance00=sqrt((pointList(j+1,1)-pointList(j,1))^2+(pointList(j+1,2)-pointList(j,2))^2);
    s=s+distance00;
end

end