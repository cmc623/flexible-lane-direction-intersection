resultAll=[];

for suijishu=1:1
    for bili=1:4
        result=[];
        for liuliang=1:5
            temp1=[];
            load(['1_Result_',num2str(suijishu),'_',num2str(liuliang),'_',num2str(bili),'.mat'])
            result_averageTimeCalculate
            temp1=[temp1,averageTime];
            load(['2_Result_',num2str(suijishu),'_',num2str(liuliang),'_',num2str(bili),'.mat'])
            result_averageTimeCalculate
            temp1=[temp1,averageTime];
            load(['3_Result_',num2str(suijishu),'_',num2str(liuliang),'_',num2str(bili),'.mat'])
            result_averageTimeCalculate
            temp1=[temp1,averageTime];
            result=[result;temp1]
            resultAll=[resultAll;temp1];
        end
    end
end
for suijishu=1:1
    for bili=1:4

        result=resultAll((bili-1)*5+1:bili*5,:);
        figure(bili)
        clf
        bar(result)
        hold on
        grid minor
        legend('Variable lanes','Fixed lanes','Signal control')
        ylabel('Average travelling time (s)')
        xlabel('Input traffic volume')
        set(gca,'XTick',1:5);
        set(gca,'XTickLabel',{'1000','2000','3000','4000','5000'});
        set(gca,'fontname', 'times new roman')
        set(gca,'fontsize', 15)
        if bili==1 || bili==4
            set(gca,'YLim',[0 100]);
        elseif bili==2
            set(gca,'YLim',[0 250]);
        elseif bili==3
            set(gca,'YLim',[0 250]);
        end

    end
end

