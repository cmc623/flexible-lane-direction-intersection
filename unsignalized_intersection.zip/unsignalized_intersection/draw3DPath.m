function draw3DPath(paths,nodeConstraintsIter,edgeConstraintsIter)
colorGroup=[  1,      0,      0;
    0,      0,      1;
    1,      0,      1;
    0,      0,    0.3;
    0.3,      0,      0;
    0.7,    0.3,      0;
    1,    0.4,      0;
    1,      1,      0;
    0.3,    0.3,      1;
    1,    0.7,    0.7;
    0.7,    0.7,      1];
colorGroup=[colorGroup;colorGroup;colorGroup;colorGroup;colorGroup];
hold on
if isempty(nodeConstraintsIter)==0
    nodeConstraintsIterNum=length(nodeConstraintsIter(:,1));
else
    nodeConstraintsIterNum=0;
end

if isempty(edgeConstraintsIter)==0
    edgeConstraintsIterNum=length(edgeConstraintsIter(:,1));
else
    edgeConstraintsIterNum=0;
end

vehicleNum=length(paths(:,1));

for i=1:nodeConstraintsIterNum
    scatter3(nodeConstraintsIter(i,1),nodeConstraintsIter(i,2),nodeConstraintsIter(i,3),350,colorGroup(nodeConstraintsIter(i,4),:),'linewidth', 1.5)
end

for i=1:edgeConstraintsIterNum
    plot3([edgeConstraintsIter(i,1),edgeConstraintsIter(i,1)+edgeConstraintsIter(i,4)],[edgeConstraintsIter(i,2),edgeConstraintsIter(i,2)+edgeConstraintsIter(i,5)],[edgeConstraintsIter(i,3),edgeConstraintsIter(i,3)+edgeConstraintsIter(i,6)],'Color',colorGroup(edgeConstraintsIter(i,7),:),'LineWidth',5)
end

for i=1:vehicleNum
    path=paths{i,1};
    pathLength=length(path(:,1));
    
    for j=1:pathLength
        if j==1
            scatter3(path(j,1),path(j,2),j,200,colorGroup(i,:),'filled')
        else
            scatter3(path(j,1),path(j,2),j,200,colorGroup(i,:),'filled')
            plot3([path(j-1,1),path(j,1)],[path(j-1,2),path(j,2)],[j-1,j],'Color',colorGroup(i,:))
        end
    end
    
end

view([-0.6,-1,1]);
grid on
axis equal

end

