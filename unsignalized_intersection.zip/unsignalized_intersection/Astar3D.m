function [openS,closeS]=Astar3D(map,barriers,barrierEdges)

barriers;


[x,y]=size(map);
closeS=struct('x',-1,'y',-1,'t',-1,'g',0,'h',0,'fx',-1,'fy',-1,'ft',-1); %????????????????????????
closelen=1;
openS=struct('x',-1,'y',-1,'t',-1,'g',-1,'h',-1,'fx',-1,'fy',-1,'ft',-1); %????????????????????????
openlen=0;
bindex=1;

% scatter3(0,0,1,1,'r','filled')
% hold on
% scatter3(x,y,1,1,'r','filled')

if isempty(barriers)==0
    barrierNum=length(barriers(:,1));
    for i=1:barrierNum
        %         scatter3(barriers(i,1),barriers(i,2),barriers(i,3),300,'b')
    end
end

if isempty(barrierEdges)==0
    barrierNum=length(barrierEdges(:,1));
    for i=1:barrierNum
        %         plot3([barrierEdges(i,1),barrierEdges(i,1)+barrierEdges(i,4)],[barrierEdges(i,2),barrierEdges(i,2)+barrierEdges(i,5)],[barrierEdges(i,3),barrierEdges(i,3)+barrierEdges(i,6)],'b','LineWidth',5)
    end
end


% for k=1:x
%     for j=1:y
%         if map(k,j)==1
%             barrierx(bindex)=-k;
%             barriery(bindex)=j;
%             bindex=bindex+1;
%         end
%     end
% end
%????????????
for i=1:x
    for j=1:y
        if map(i,j)==2 || map(i,j)==7
            endx=i;
            endy=j;
            endt=1;
            break;
        end
    end
end
%????????????????????close
for i=1:x
    for j=1:y
        if map(i,j)==5|| map(i,j)==7
            startx=i;
            starty=j;
            closeS(1).x=i;
            closeS(1).y=j;
            closeS(1).t=1;
            break;
        end
    end
end
%??????????????????open
%????????
% direct=[0 -1 1;0 1 1;-1 0 1;1 0 1;
%     1 -1 1;1 1 1;-1 1 1;-1 -1 1;0 0 1];

direct=[-1 0 1;1 0 1;0 0 1;0 -1 1;0 1 1];
% direct=[0 0 1;0 -1 1;0 1 1;-1 0 1;1 0 1];
for i=1:length(direct(:,1))
    if all([closeS(1).x,closeS(1).y]+direct(i,1:2)>0)     && closeS(1).x+direct(i,1)<=x && closeS(1).y+direct(i,2)<=y     && IsBarrier(barriers,[closeS(1).x+direct(i,1),closeS(1).y+direct(i,2),closeS(1).t+direct(i,3)])==0  && IsBarrierEdge(barrierEdges,[closeS(1).x,closeS(1).y,closeS(1).t],[direct(i,1),direct(i,2),direct(i,3)])==0
        openS(openlen+1).x=closeS(1).x+direct(i,1);
        openS(openlen+1).y=closeS(1).y+direct(i,2);
        openS(openlen+1).t=closeS(1).t+direct(i,3);
        openS(openlen+1).fx=closeS(1).x;
        openS(openlen+1).fy=closeS(1).y;
        openS(openlen+1).ft=closeS(1).t;
        openlen=openlen+1;
        %????g??????h????????
        openS(openlen).g=1;
        openS(openlen).h=abs(endx-openS(openlen).x)+abs(endy-openS(openlen).y);
        
%         hold on
%         scatter3(openS(openlen).x,openS(openlen).y,openS(openlen).t,300,'b','filled')
%         pause(0.5)
%         view([-0.6,-1,1]);
%         grid on
%         axis equal
    end
end
% close
% open.h


% scatter3(closeS(closelen).x,closeS(closelen).y,closeS(closelen).t,200,'r','filled')

%????????open??yse????????????????????????????????????
% disp(['###111###111###',num2str(endx),num2str(endy)])
openlen;
while openlen>0
    
    %????????????g+h????open????????
    min = realmax;
    for i=1:openlen
        if openS(i).g+openS(i).h<=min
            min=openS(i).g+openS(i).h;
            sindex=i;
        end
    end
    
    %??s????????close????????open??
    closeS(closelen+1).x=openS(sindex).x;
    closeS(closelen+1).y=openS(sindex).y;
    closeS(closelen+1).t=openS(sindex).t;
    closeS(closelen+1).g=openS(sindex).g;
    closeS(closelen+1).h=openS(sindex).h;
    closeS(closelen+1).fx=openS(sindex).fx;
    closeS(closelen+1).fy=openS(sindex).fy;
    closeS(closelen+1).ft=openS(sindex).ft;
    
%     newClose=[closeS(closelen+1).x;closeS(closelen+1).y;closeS(closelen+1).t]
    
    closelen=closelen+1;
    openlen=openlen-1;
    for i=sindex:openlen
        openS(i)=openS(i+1);
    end
    openS(openlen+1)=[];
    %     openlen=0;
    
    %??????????
    %     pause(0.01)
    %     img = zeros(x,y);
    %     img(startx,starty)=10;
    %     for k=1:x
    %         for j=1:y
    %             if map(k,j)==1
    %                 img(k,j)=5;
    %             end
    %         end
    %     end
    %     for k=2:closelen
    %         img(close(k).x,close(k).y)=3;
    %     end
    %     img(endx,endy)=10;
    %     imagesc(img*10);
%     hold on
%     scatter3(closeS(closelen).x,closeS(closelen).y,closeS(closelen).t,200,'r','filled')
%     pause(0.5)
%     view([-0.6,-1,1]);
%     grid on
%     axis equal
    %     plot3([closeS(closelen).fx,closeS(closelen).x],[closeS(closelen).fy,closeS(closelen).y],[closeS(closelen).ft,closeS(closelen).t],'r')
    %     hold on
    
    %�ж��Ƿ񵽴���end
    if closeS(closelen).x == endx && closeS(closelen).y==endy
        
        
        
        vehicleX=[closeS.x];
        vehicleY=[closeS.y];
        vehicleT=[closeS.t];
        vehicleFX=[closeS.fx];
        vehicleFY=[closeS.fy];
        vehicleFT=[closeS.ft];
        
        numTemp=length(vehicleX);
        
        endX=vehicleX(numTemp);
        endY=vehicleY(numTemp);
        endT=vehicleT(numTemp);
        
        fX=vehicleFX(numTemp);
        fY=vehicleFY(numTemp);
        fT=vehicleFT(numTemp);
        
        pathSingle=[endX,endY,endT];
        
        while(fX~=vehicleX(1)||fY~=vehicleY(1)||fT~=vehicleT(1))
            if vehicleFX<0
                break
            end
            for j=1:numTemp
                if vehicleX(j)==fX && vehicleY(j)==fY && vehicleT(j)==fT
                    pathSingle=[fX,fY,fT;pathSingle];
                    fX=vehicleFX(j);
                    fY=vehicleFY(j);
                    fT=vehicleFT(j);
                    break
                end
            end
        end
        
        if endX~=vehicleX(1) || endY~=vehicleY(1)
            pathSingle=[vehicleX(1),vehicleY(1),vehicleT(1);pathSingle];
        end
        
        if pathSingle(1)==-1
            pathSingle(1)=vehicles(i,1);
            pathSingle(2)=vehicles(i,2);
            pathSingle(3)=1;
        end
        
        pathSingle;
        pathLength=length(pathSingle(:,1));
        barriers;
        
        breakFlag=1;
        if isempty(barriers)==0
            barrierNum=length(barriers(:,1));
            
            for i=1:barrierNum
                if barriers(i,1)==endx && barriers(i,2)==endy && barriers(i,3)>=closeS(closelen).t
%                     disp('13246583543246534376815578364182')
                    breakFlag=0;
                end
            end
        end
        
        barrierEdges;
        if isempty(barrierEdges)==0
            barrierNum=length(barrierEdges(:,1));
            for i=1:barrierNum
                if barrierEdges(i,1)==endx && barrierEdges(i,2)==endy && barrierEdges(i,4)==0 && barrierEdges(i,5)==0 && barrierEdges(i,3)+1>=closeS(closelen).t
%                     disp('13246583543246534376815578364182')
                    breakFlag=0;
                end
            end
        end
        
        
        if breakFlag==1
            %                 disp('BREAK!!!!!!!!!!!!!!!!!!!!!')
            break
        end
        
    end
    
    %??????????????????????????????????????????open??
    for i=1:length(direct(:,1))
        if all([closeS(closelen).x,closeS(closelen).y]+direct(i,1:2)>0)  && closeS(closelen).x+direct(i,1)<=x && closeS(closelen).y+direct(i,2)<=y && IsBarrier(barriers,[closeS(closelen).x+direct(i,1),closeS(closelen).y+direct(i,2),closeS(closelen).t+direct(i,3)])==0 && IsBarrierEdge(barrierEdges,[closeS(closelen).x,closeS(closelen).y,closeS(closelen).t],[direct(i,1),direct(i,2),direct(i,3)])==0
            %????????????close??
            flag=false;
            for m=1:closelen
                if closeS(m).x==closeS(closelen).x+direct(i,1)                && closeS(m).y==closeS(closelen).y+direct(i,2)    && closeS(m).t==closeS(closelen).t+direct(i,3)
                    flag=true;
                    break;
                end
            end
            if flag
                continue;
            end
            
            %????????????open??
            flag=false;
            for m=1:openlen
                if openS(m).x==closeS(closelen).x+direct(i,1)                && openS(m).y==closeS(closelen).y+direct(i,2)     && openS(m).t==closeS(closelen).t+direct(i,3)
                    flag=true;
                    break;
                end
            end
            if flag
                %more????????
                continue;
            else  %open??????????
                openS(openlen+1).x=closeS(closelen).x+direct(i,1);
                openS(openlen+1).y=closeS(closelen).y+direct(i,2);
                openS(openlen+1).t=closeS(closelen).t+direct(i,3);
                openS(openlen+1).fx=closeS(closelen).x;
                openS(openlen+1).fy=closeS(closelen).y;
                openS(openlen+1).ft=closeS(closelen).t;
                openlen=openlen+1;
                %????g??????h????????
                openS(openlen).g=closeS(closelen).g+1;
                openS(openlen).h=abs(endx-openS(openlen).x)+abs(endy-openS(openlen).y);
                h=openS(openlen).h;
                
%                 hold on
%                 scatter3(openS(openlen).x,openS(openlen).y,openS(openlen).t,300,'b','filled')
%                 pause(0.5)
%                 view([-0.6,-1,1]);
%                 grid on
%                 axis equal
            end
        end
    end
end
% disp('END!!!!!!!!!!!!!!!!!!!!!')