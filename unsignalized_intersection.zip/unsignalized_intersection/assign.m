function[f,D,G]=assign(B)
%disp('Hungarian');
n=length(B(:,1));
u=min(B,[],2);
f=sum(u);%���ڼ�¼����ֵ
B=B-repmat(u,1,n);
v=min(B,[],1);
f=f+sum(v);%���ڼ�¼����ֵ
B=B-repmat(v,n,1);
C=zeros(n);
while 1
    C(find(B==0))=1;
    E=C;
    u=sum(C,2);
    v=sum(C);
    D=zeros(1,n);
    G=zeros(1,n);
    [C,D,G,E,u,v]=assignz(C,D,G,E,u,v);
    num=-1;
    while num<0
        add=find(D==0);
        if isempty(add)
            return;
        end
        [D,G,E,SP,TP]=assignln(D,G,E,add);
        num=numel(SP)-numel(TP);
    end
    add=setdiff(1:n,TP);
    m=min(min(B(SP,add)));
    B(SP,add)=B(SP,add)-m;
    add=setdiff(1:n,SP);
    B(add,TP)=B(add,TP)+m;
    f=f+m*num;
end