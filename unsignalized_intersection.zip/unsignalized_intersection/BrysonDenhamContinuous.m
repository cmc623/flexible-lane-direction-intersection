function phaseout = BrysonDenhamContinuous(input)

phaseTimes=size(input.phase,2);

for i=1:phaseTimes
    x2 = input.phase(i).state(:,2);
    
    u = input.phase(i).control;
    
    dx1 = x2;
    dx2 = u;
    dx3 = (u.^2)./2;
    
    phaseout(i).dynamics = [dx1, dx2, dx3];
end
