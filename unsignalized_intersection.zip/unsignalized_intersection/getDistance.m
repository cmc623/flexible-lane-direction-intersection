function [Distance] = getDistance(Agent,Goal)
n=length(Agent(:,1));
m=length(Goal(:,1));
for i=1:n
    for j=1:m
        Distance(i,j)=((Agent(i,1)-Goal(j,1))*3)^2+(Agent(i,2)-Goal(j,2))^2;
        
    end
end
end

