function [nodeConstraints,edgeConstraints,constraintTree,conflictFlag] = conflictCheck(paths,nodeConstraints,edgeConstraints,constraintTree,assignSort)

vehicleNum=length(paths(:,1));
pathsLength=paths{1,2}-1;

conflictFlag=0;

% newConflictFlag=0;

newNodeConstraints=[];
newEdgeConstraints=[];

% disp('@#@#@#@#@#@#@#@#@#@#@#@#@#')
constraintTree;

lowerBound=0;

if isempty(constraintTree)==0
    treeLength=length(constraintTree(:,1));
    for j=1:treeLength
        if constraintTree{j,3}==1
            nodeConflictBase=constraintTree{j,1};
            edgeConflictBase=constraintTree{j,2};
            
            lowerBound=constraintTree{j,4};
            
        end
    end
else
    treeLength=0;
    nodeConflictBase=[];
    edgeConflictBase=[];
end


pathsLength;
for i=1:pathsLength+1
    i;
    paths;
    nodeInConflict=[];
    edgeInConflict=[];
    
    if i==2
        temp=1;
    end
    
    for j=1:vehicleNum
        j;
        pathJ=paths{j,1};
        for k=1:vehicleNum
            k;
            pathK=paths{k,1};
            if pathJ(i,1)==pathK(i,1) && pathJ(i,2)==pathK(i,2) && j~=k
                if ismember(j,nodeInConflict)==0
                    nodeInConflict=[nodeInConflict;j];
                end
                if ismember(k,nodeInConflict)==0
                    nodeInConflict=[nodeInConflict;k];
                end
            end
        end
    end
    nodeInConflict;
    
    if i~=1
        for j=1:vehicleNum
            pathJ=paths{j,1};
            for k=1:vehicleNum
                pathK=paths{k,1};
                if pathJ(i-1,1)==pathK(i,1) && pathJ(i-1,2)==pathK(i,2) && pathJ(i,1)==pathK(i-1,1) && pathJ(i,2)==pathK(i-1,2) && j~=k %��λ��ͻ
                    if ismember(j,edgeInConflict)==0
                        edgeInConflict=[edgeInConflict;j];
                    end
                    if ismember(k,edgeInConflict)==0
                        edgeInConflict=[edgeInConflict;k];
                    end
                end
                if pathJ(i-1,1)+pathJ(i,1)==pathK(i-1,1)+pathK(i,1) && pathJ(i-1,2)+pathJ(i,2)==pathK(i-1,2)+pathK(i,2)  && j~=k %�����ͻ
                    if ismember(j,edgeInConflict)==0
                        edgeInConflict=[edgeInConflict;j];
                    end
                    if ismember(k,edgeInConflict)==0
                        edgeInConflict=[edgeInConflict;k];
                    end
                end
                if pathJ(i-1,1)~=pathJ(i,1) && pathJ(i-1,2)~=pathJ(i,2)  && j~=k %������ײ��ͻ
%                     disp('!!~!!~!!~!!~!~!~!!~!~!~!~!!~!~!~!~!')
                    x1=pathJ(i-1,1);
                    y1=pathJ(i-1,2);
                    x2=pathJ(i,1);
                    y2=pathJ(i,2);
                    xx1=pathK(i-1,1);
                    yy1=pathK(i-1,2);
                    xx2=pathK(i,1);
                    yy2=pathK(i,2);
                    aaaa=[x1,y1,x2,y2,xx1,yy1,xx2,yy2];
                    if processConflictCheck(x1,y1,x2,y2,xx1,yy1,xx2,yy2)==1
                        if ismember(j,edgeInConflict)==0
                            edgeInConflict=[edgeInConflict;j];
                        end
                        if ismember(k,edgeInConflict)==0
                            edgeInConflict=[edgeInConflict;k];
                        end
                    end
                end
            end
        end
    end
    edgeInConflict;
    
    
    
    if isempty(nodeInConflict)==0
        for j=1:length(nodeInConflict)
            pathTemp=paths{nodeInConflict(j),1};
            
            newNodeConstraint=[pathTemp(i,1),pathTemp(i,2),i,nodeInConflict(j)];
            if isempty(nodeConstraints)==0
                nodeConstraintsNum=length(nodeConstraints(:,1));
            else
                nodeConstraintsNum=0;
            end
            
            sameID=0;

            for k=1:nodeConstraintsNum
                if newNodeConstraint(1)==nodeConstraints(k,1) && newNodeConstraint(2)==nodeConstraints(k,2) && newNodeConstraint(3)==nodeConstraints(k,3) && newNodeConstraint(4)==nodeConstraints(k,4)
                    sameID=k;
                    break
                end
            end
            
            
            paths;
            addFlag=1;
            for k=1:vehicleNum
                vehiclePath=paths{k,1};
                vehiclePathLength=length(vehiclePath(:,1));
                if vehiclePath(vehiclePathLength,1)~=assignSort(k,1) || vehiclePath(vehiclePathLength,2)~=assignSort(k,2)
                    addFlag=0;
                    break
                end
            end
            if addFlag==1
                if sameID==0
                    nodeConstraints=[nodeConstraints;newNodeConstraint];
                    constraintTree=[constraintTree;{[nodeConflictBase;length(nodeConstraints(:,1))],edgeConflictBase,0,lowerBound,0}];
                else
                    constraintTree=[constraintTree;{[nodeConflictBase;sameID],edgeConflictBase,0,lowerBound,0}];
                end
            end
            
            
        end
    end
    nodeConstraints;
    constraintTree;
    
    if isempty(edgeInConflict)==0
        for j=1:length(edgeInConflict)
            pathTemp=paths{edgeInConflict(j),1};
            
            newEdgeConstraint=[pathTemp(i-1,1),pathTemp(i-1,2),i-1,pathTemp(i,1)-pathTemp(i-1,1),pathTemp(i,2)-pathTemp(i-1,2),1,edgeInConflict(j)];
            if isempty(edgeConstraints)==0
                edgeConstraintsNum=length(edgeConstraints(:,1));
            else
                edgeConstraintsNum=0;
            end
            
            sameID=0;

            for k=1:edgeConstraintsNum
                if newEdgeConstraint(1)==edgeConstraints(k,1) && newEdgeConstraint(2)==edgeConstraints(k,2) && newEdgeConstraint(3)==edgeConstraints(k,3) && newEdgeConstraint(4)==edgeConstraints(k,4) && newEdgeConstraint(5)==edgeConstraints(k,5) && newEdgeConstraint(6)==edgeConstraints(k,6) && newEdgeConstraint(7)==edgeConstraints(k,7)
                    sameID=k;
                    break
                end
            end
            
            addFlag=1;
            for k=1:vehicleNum
                vehiclePath=paths{k,1};
                vehiclePathLength=length(vehiclePath(:,1));
                if vehiclePath(vehiclePathLength,1)~=assignSort(k,1) || vehiclePath(vehiclePathLength,2)~=assignSort(k,2)
                    addFlag=0;
                    break
                end
            end
            if addFlag==1
                if sameID==0
                    edgeConstraints=[edgeConstraints;newEdgeConstraint];
                    constraintTree=[constraintTree;{nodeConflictBase,[edgeConflictBase;length(edgeConstraints(:,1))],0,lowerBound,0}];
                else
                    constraintTree=[constraintTree;{nodeConflictBase,[edgeConflictBase;sameID],0,lowerBound,0}];
                end
            end
            
        end
    end
    edgeConstraints;
    constraintTree;
    
    if isempty(nodeInConflict)==0 || isempty(edgeInConflict)==0
        conflictFlag=1;
        break
    end
    
end

if isempty(constraintTree)==0
    treeLength=length(constraintTree(:,1));
    for j=1:treeLength
        if constraintTree{j,3}==1
            constraintTree{j,3}=2;
        end
    end
end

end

