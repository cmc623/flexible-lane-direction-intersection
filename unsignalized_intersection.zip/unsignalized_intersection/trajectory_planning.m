function [pointList,curve]=trajectory_planning(vehicle,goal,gap)

kk=2.5;
gap=gap/kk;

CtrlPoint4=[vehicle(1),vehicle(2);
    vehicle(1)+gap*sind(vehicle(3)),vehicle(2)+gap*cosd(vehicle(3));
    goal(1)-gap*sind(goal(3)),goal(2)-gap*cosd(goal(3));
    goal(1),goal(2)];

% vehicle
% goal
CtrlPoint4;
% 
% scatter(CtrlPoint4(1:3,1),CtrlPoint4(1:3,2))
% hold on
gap=gap*kk;
%������������
[pointList,curve]=PointOnBezier(0,round(gap),CtrlPoint4);

end