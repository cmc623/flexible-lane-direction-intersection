stateNum=length(vehicleState);
startTime=0;
endTime=0;
IDList=[];
for i=1:stateNum
    thisState=vehicleState{i};
    if isempty(thisState)==0
        vehicleNum=length(thisState(:,1));
        for j=1:vehicleNum
            vehicleID=thisState(j,1);
            if ismember(vehicleID,IDList)
                
            end
        end
    end
    
end
endTime=stateNum/10;
maxTime=endTime-startTime