
% rng('shuffle');



conflictMap=[
    1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 0 0 0 0 0 0
    0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0  0 0 0 0 0 0 1 1 0  0 0 0 0 0 0 0 0 0
    0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0  0 0 0 0 0 0 1 1 1  0 0 0 0 0 0 0 0 0
    0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0  0 0 0 0 0 0 1 1 1  1 1 1 1 1 1 1 1 1
    0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0  0 0 0 0 0 0 1 1 1  0 1 1 1 1 1 1 1 1
    0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1  0 0 0 0 0 0 1 1 1  0 0 1 1 1 1 1 1 1
    0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1  1 1 1 1 1 1 1 1 1  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1  0 1 1 1 1 1 1 1 1  0 0 0 0 1 1 1 1 1
    0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1  0 0 1 1 1 1 1 1 0  0 0 0 0 0 1 1 1 1
    
    0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0  0 0 0 0 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0  0 0 0 0 0 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1  1 1 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1  0 1 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1  0 0 1 1 1 1 1 1 0
    
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1
    
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1
    ];

conflictMapNum=length(conflictMap(1,:));
for i=1:conflictMapNum
    for j=i+1:conflictMapNum
        conflictMap(j,i)=conflictMap(i,j);
    end
end



global Acc_Speed_Count
global Count_all
Count_all=[0,0,0,0,1];
for tflow_i = 1:length(Tflow)
    disp('Multi');
    tflow_i
    Last_Error={'aaa',1};
    %% Output defination
    % CAV_List:
    % Col_1         Col_2       Col_3           Col_4       Col_5
    % Vehicle_ID    Status      Control_Step    solution    Control_Time
    % Col_6             Col_7                   Col_8
    % Control_Speed     Pass_vehicle    Time_to_Trafficlight
    % Col_9                 Col_10
    % Target_Green_Start
    
    % Data_record
    % Col_1         Col_2           Col_3               Col_4           Col_5
    % vehicle_ID    vehicle_Type    Vehicle_Position    Vehicle_Speed   Fuel_Consumotion
    
    %% Path
    simulation_step = 0.1;
    
    simulation_folder = 'traci_tls\data';
    scenarioPath = fullfile(simulation_folder,'cross.sumocfg');
    routePath = fullfile(simulation_folder,'cross.rou.xml');
    nodPath = fullfile(simulation_folder,'cross.nod.xml');
    edgePath = fullfile(simulation_folder,'cross.edg.xml');
    connPath = fullfile(simulation_folder,'cross.con.xml');
    sumoHome = getenv('SUMO_HOME');
    
    %% Flags
    SUMO_GUI = 'true';
    
    %% Parameters
    Penetration_Rate = 0.9;
    Total_Simulation_Vehicle = 300;
    Test_Speed = 10;
    Test_Platoon_Size = 9;
    
    % Vehicle_Per_Hour = 800;
    % Test_Depart_Gap = 1./(Vehicle_Per_Hour / 3600);
    % Test_Depart_Gap = floor(Test_Depart_Gap * 10)/10;
    
    Test_Depart_Gap = 5.1;
    
    % Depart_Gap = 5; %s
    intersection_offset = 8.55;
    RegularPlatoonSize = 10;
    Min_Gap = 2;
    Reaction_Time = 1;
    Vehicle_length = 4;
    Max_speed = 14.66;
    Simulation_Total_Time = 0;
    Min_acc = -6;
    Max_acc = 3;
    
    Load_length = 400;
    Load_length2 = 600;
    
    
    Ring1=15;
    Ring2=300;
    Ring3=300;%����
    Ring4=500;
    Ring5=700;
    Ring6=950;
    
    vehicle_Gap=30;%�����ڵĸ������
    
    All_Intersection_direction = {'E_L','E_F','E_R','S_L','S_F','S_R','W_L','W_F','W_R','N_L','N_F','N_R'};%F��ʾforward
    All_Leg = {'W','S','E','N'};
    All_Direction = {'L','F','R'};
    
    Vehicle_List1={};
    Vehicle_List2={};
    Vehicle_List3={};
    Vehicle_List4={};
    
    Vehicle_List=cell(1,4);
    All_Vehicle_List={};
    
    All_Route=cell(4,3);
    
    All_Route(1,1)={['West','_in_','North','_out']};
    All_Route(1,2)={['West','_in_','East','_out']};
    All_Route(1,3)={['West','_in_','South','_out']};
    
    All_Route(2,1)={['South','_in_','West','_out']};
    All_Route(2,2)={['South','_in_','North','_out']};
    All_Route(2,3)={['South','_in_','East','_out']};
    
    All_Route(3,1)={['East','_in_','South','_out']};
    All_Route(3,2)={['East','_in_','West','_out']};
    All_Route(3,3)={['East','_in_','North','_out']};
    
    All_Route(4,1)={['North','_in_','East','_out']};
    All_Route(4,2)={['North','_in_','South','_out']};
    All_Route(4,3)={['North','_in_','West','_out']};
    
    save Parameter.mat
    tic
    New_Connections1();
    New_Road();
    New_Edge();
    New_Vehicle_REF();
    
    drawFigure=1;
    
    vehicleNum=4;
    
    speedCount={'aaa',0,0};
    roadGap=30;
    
    accCount={'aaa',0,0,0,0};
    vehicleYES=0;
    
    vehicleGroupsLayer={};
    
    
    Acc_Speed_Count={'aaa',1,1,1,1,1,1};
    
    global X1 X2 X3 vF T laneWidth dt gap
    X1=0;
    X2=1000;
    X3=1200;
    vF=10;
    T=4;
    laneWidth=3.3;
    dt=simulation_step;
    gap=17;
    
    vehicleGenerateCount=0;
    
    vehicleSpeedList=cell(1,4);
    vehicleChangeLaneList=cell(1,4);
    deleteSet=[];
    
    vehicleState={};
    
    
    %% GUI SET COMMANDS
    
    for Simulation_Depart_Gap = 1:length(Test_Depart_Gap)
        Depart_Gap = Test_Depart_Gap(Simulation_Depart_Gap);
        ArriveTimePlan = [];
        save('Variables.mat','ArriveTimePlan')
        save Parameter.mat
        
        switch SUMO_GUI
            case 'true'
                %                 traci.start(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --start' ' --quit-on-end']);
                %                 system(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --lanechange.duration 1' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                system(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --lanechange.duration 2' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                traci.init();
                traci.gui.setSchema('View #0','real world');
            case 'false'
                %                 traci.start(['sumo-gui ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --start' ' --quit-on-end']);
                system(['sumo -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                traci.init();
            otherwise
                continue;
        end
        
        %% Main
        
        step=0;
        
        
        
        while step <((1/simulation_step)*1000000000)
            if step==0
                vehicleList=[];
                vehicleIDList={};
            end
            
            step = step + 1;
            str12=num2str(step);
            %%%disp(str12);
            traci.simulationStep();
            %             disp('1121212121212121221')
            %             traci.trafficlights.setRedYellowGreenState('Center','OOOOOOOOOOOOOOOOOOOOO');
            %             disp('###################')
            if step>(1/simulation_step)*2000000
                drawFigure=1;
            else
                drawFigure=0;
            end
            %2��·�ڣ�1��ͶӰ
            
            if drawFigure==2
                clf
                Load_length=Load_length*2;
                a=fill([0,Load_length,Load_length,0],[Load_length/2-10,Load_length/2-10,Load_length/2+10,Load_length/2+10],[1,1,1]);
                set(a,{'LineStyle'},{'none'})
                hold on
                a=fill([Load_length/2-10,Load_length/2-10,Load_length/2+10,Load_length/2+10],[0,Load_length,Load_length,0],[1,1,1]);
                set(a,{'LineStyle'},{'none'})
                hold on
                
                a=fill([Load_length/2-10,Load_length/2-10,Load_length/2,Load_length/2],[Load_length/2+10,Load_length,Load_length,Load_length/2+10],[0.88,0.94,0.85]);
                set(a,{'LineStyle'},{'none'})
                a=fill([Load_length/2,Load_length/2,Load_length/2+10,Load_length/2+10],[0,Load_length/2-10,Load_length/2-10,0],[0.88,0.94,0.85]);
                set(a,{'LineStyle'},{'none'})
                a=fill([0,Load_length/2-10,Load_length/2-10,0],[Load_length/2-10,Load_length/2-10,Load_length/2,Load_length/2],[0.88,0.94,0.85]);
                set(a,{'LineStyle'},{'none'})
                a=fill([Load_length/2+10,Load_length,Load_length,Load_length/2+10],[Load_length/2,Load_length/2,Load_length/2+10,Load_length/2+10],[0.88,0.94,0.85]);
                set(a,{'LineStyle'},{'none'})
                
                plot([0,Load_length/2-10],[Load_length/2,Load_length/2],'Color','k','LineWidth',1);
                plot([0,Load_length/2-10],[Load_length/2+1*3.33,Load_length/2+1*3.33],'--k','LineWidth',1);
                plot([0,Load_length/2-10],[Load_length/2+2*3.33,Load_length/2+2*3.33],'--k','LineWidth',1);
                plot([0,Load_length/2-10],[Load_length/2-1*3.33,Load_length/2-1*3.33],'--k','LineWidth',1);
                plot([0,Load_length/2-10],[Load_length/2-2*3.33,Load_length/2-2*3.33],'--k','LineWidth',1);
                plot([0,Load_length/2-10],[Load_length/2-10,Load_length/2-10],'Color','k','LineWidth',1);
                plot([0,Load_length/2-10],[Load_length/2+10,Load_length/2+10],'Color','k','LineWidth',1);
                
                plot([Load_length/2+10,Load_length],[Load_length/2,Load_length/2],'Color','k','LineWidth',1);
                plot([Load_length/2+10,Load_length],[Load_length/2+1*3.33,Load_length/2+1*3.33],'--k','LineWidth',1);
                plot([Load_length/2+10,Load_length],[Load_length/2+2*3.33,Load_length/2+2*3.33],'--k','LineWidth',1);
                plot([Load_length/2+10,Load_length],[Load_length/2-1*3.33,Load_length/2-1*3.33],'--k','LineWidth',1);
                plot([Load_length/2+10,Load_length],[Load_length/2-2*3.33,Load_length/2-2*3.33],'--k','LineWidth',1);
                plot([Load_length/2+10,Load_length],[Load_length/2+10,Load_length/2+10],'Color','k','LineWidth',1);
                plot([Load_length/2+10,Load_length],[Load_length/2-10,Load_length/2-10],'Color','k','LineWidth',1);
                
                plot([Load_length/2,Load_length/2],[0,Load_length/2-10],'Color','k','LineWidth',1);
                plot([Load_length/2+1*3.33,Load_length/2+1*3.33],[0,Load_length/2-10],'--k','LineWidth',1);
                plot([Load_length/2+2*3.33,Load_length/2+2*3.33],[0,Load_length/2-10],'--k','LineWidth',1);
                plot([Load_length/2-1*3.33,Load_length/2-1*3.33],[0,Load_length/2-10],'--k','LineWidth',1);
                plot([Load_length/2-2*3.33,Load_length/2-2*3.33],[0,Load_length/2-10],'--k','LineWidth',1);
                plot([Load_length/2+10,Load_length/2+10],[0,Load_length/2-10],'Color','k','LineWidth',1);
                plot([Load_length/2-10,Load_length/2-10],[0,Load_length/2-10],'Color','k','LineWidth',1);
                
                plot([Load_length/2,Load_length/2],[Load_length/2+10,Load_length],'Color','k','LineWidth',1);
                plot([Load_length/2+1*3.33,Load_length/2+1*3.33],[Load_length/2+10,Load_length],'--k','LineWidth',1);
                plot([Load_length/2+2*3.33,Load_length/2+2*3.33],[Load_length/2+10,Load_length],'--k','LineWidth',1);
                plot([Load_length/2-1*3.33,Load_length/2-1*3.33],[Load_length/2+10,Load_length],'--k','LineWidth',1);
                plot([Load_length/2-2*3.33,Load_length/2-2*3.33],[Load_length/2+10,Load_length],'--k','LineWidth',1);
                plot([Load_length/2+10,Load_length/2+10],[Load_length/2+10,Load_length],'Color','k','LineWidth',1);
                plot([Load_length/2-10,Load_length/2-10],[Load_length/2+10,Load_length],'Color','k','LineWidth',1);
                
                Load_length=Load_length/2;
            end
            if drawFigure==1
                
                legBegin=0;
                legEnd=Load_length;
                
                laneNum=3;
                laneWidth=3.3;
                clf
                hold on
                
                %West
                fill([legBegin,legBegin,legEnd,legEnd],[Load_length,Load_length-laneWidth*laneNum,Load_length-laneWidth*laneNum,Load_length],[0.88,0.94,0.85])
                
                plot([legBegin,legEnd],[Load_length,Load_length],'Color','k','LineWidth',1)
                for m=1:laneNum-1
                    plot([legBegin,legEnd],[Load_length-laneWidth*m,Load_length-laneWidth*m],'--','Color','k','LineWidth',0.6)
                end
                plot([legBegin,legEnd],[Load_length-laneWidth*laneNum,Load_length-laneWidth*laneNum],'Color','k','LineWidth',1)
                
                
                
                %South
                fill([legBegin,legBegin,legEnd,legEnd],[Load_length-roadGap,Load_length-laneWidth*laneNum-roadGap,Load_length-laneWidth*laneNum-roadGap,Load_length-roadGap],[0.88,0.94,0.85])
                plot([legBegin,legEnd],[Load_length-roadGap,Load_length-roadGap],'Color','k','LineWidth',1)
                for m=1:laneNum-1
                    plot([legBegin,legEnd],[Load_length-laneWidth*m-roadGap,Load_length-laneWidth*m-roadGap],'--','Color','k','LineWidth',0.6)
                end
                plot([legBegin,legEnd],[Load_length-laneWidth*laneNum-roadGap,Load_length-laneWidth*laneNum-roadGap],'Color','k','LineWidth',1)
                
                %East
                fill([legBegin,legBegin,legEnd,legEnd],[Load_length-2*roadGap,Load_length-laneWidth*laneNum-2*roadGap,Load_length-laneWidth*laneNum-2*roadGap,Load_length-2*roadGap],[0.88,0.94,0.85])
                plot([legBegin,legEnd],[Load_length-2*roadGap,Load_length-2*roadGap],'Color','k','LineWidth',1)
                for m=1:laneNum-1
                    plot([legBegin,legEnd],[Load_length-laneWidth*m-2*roadGap,Load_length-laneWidth*m-2*roadGap],'--','Color','k','LineWidth',0.6)
                end
                plot([legBegin,legEnd],[Load_length-laneWidth*laneNum-2*roadGap,Load_length-laneWidth*laneNum-2*roadGap],'Color','k','LineWidth',1)
                
                %North
                fill([legBegin,legBegin,legEnd,legEnd],[Load_length-3*roadGap,Load_length-laneWidth*laneNum-3*roadGap,Load_length-laneWidth*laneNum-3*roadGap,Load_length-3*roadGap],[0.88,0.94,0.85])
                plot([legBegin,legEnd],[Load_length-3*roadGap,Load_length-3*roadGap],'Color','k','LineWidth',1)
                for m=1:laneNum-1
                    plot([legBegin,legEnd],[Load_length-laneWidth*m-3*roadGap,Load_length-laneWidth*m-3*roadGap],'--','Color','k','LineWidth',0.6)
                end
                plot([legBegin,legEnd],[Load_length-laneWidth*laneNum-3*roadGap,Load_length-laneWidth*laneNum-3*roadGap],'Color','k','LineWidth',1)
                
                
                plot([Load_length-Ring1,Load_length-Ring1],[Load_length-200,Load_length+100],'Color','w','LineWidth',1);
                plot([Load_length-Ring2,Load_length-Ring2],[Load_length-200,Load_length+100],'Color','w','LineWidth',1);
                plot([Load_length-Ring3,Load_length-Ring3],[Load_length-200,Load_length+100],'Color','w','LineWidth',1);
                plot([Load_length-Ring4,Load_length-Ring4],[Load_length-200,Load_length+100],'Color','w','LineWidth',1);
                plot([Load_length-Ring5,Load_length-Ring5],[Load_length-200,Load_length+100],'Color','w','LineWidth',1);
                %             plot([Load_length-Ring6,Load_length-Ring6],[1490,Load_length],'Color','k','LineWidth',1);
                plot([Load_length-Ring6+130,Load_length-Ring6+130],[Load_length-200,Load_length+100],'Color','w','LineWidth',1);
            end
            
            
            virtual_Platoon={};
            virtual_Platoon_List=[];
            
            
            
            
            if rand(1)<Tflow(tflow_i) && vehicleGenerateCount<testVehicleNum%�����³�
                vehicleGenerateCount=vehicleGenerateCount+1;
                temp1=rand(1);
                lane=floor(temp1*3)
                
                temp2=rand(1);
                if temp2<turningRatio(1)
                    temp2=1;
                elseif temp2<turningRatio(2)
                    temp2=2;
                else
                    temp2=3;
                end
                
                goal=All_Direction{temp2};
                
                vehicleYES=1;
                
                temp3=rand(1);
                fromDir=floor(temp3*4)+1;
                if fromDir==5
                    fromDir=4;
                end
                
                
                newVehicleID = [All_Leg{fromDir},'_',goal,'_',num2str(step)];
                
                newVehicleID=num2str(step);
                
                newVehicleRoute=All_Route{fromDir,ceil(temp2)};
                
                if goal=='L'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,lane,'CAV_L');
                elseif goal=='F'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,lane,'CAV_F');
                elseif goal=='R'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,lane,'CAV_R');
                end
                traci.vehicle.setSpeedMode(newVehicleID,31);%7
                traci.vehicle.setSpeed(newVehicleID,vF);%7
                traci.vehicle.setLaneChangeMode(newVehicleID,512);
                
                All_Vehicle_List=[All_Vehicle_List,newVehicleID];
                
                
            end
            
            
            
            
            
            
            TT=1;
            if floor((step+1)/TT)~=floor(step/TT) || step==1
                vehicleIDListTemp = traci.vehicle.getIDList();
                vehicleIDList={};
                
                
                
                if isempty(vehicleIDListTemp)==0
                    for i=1:length(vehicleIDListTemp)
                        if ismember(str2num(vehicleIDListTemp{i}),deleteSet)==0
                            vehicleIDList=[vehicleIDList,vehicleIDListTemp{i}];
                        end
                    end
                end
                
                
                if isempty(vehicleIDList)==0
                    vehicleIDListNum=length(vehicleIDList);
                    vehicleList=zeros(vehicleIDListNum,15);
                    
                    for i=1:vehicleIDListNum
                        vehicleList(i,1)=str2double(vehicleIDList{i});
                        Vehicle_ID=vehicleIDList{i};
                        Temp = traci.vehicle.getPosition(Vehicle_ID);
                        vehicleList(i,2)=Temp(1);
                        vehicleList(i,3)=Temp(2);
                        vehicleList(i,4)=traci.vehicle.getAngle(Vehicle_ID);
                        vehicleList(i,5)=traci.vehicle.getSpeed(Vehicle_ID);
                        %                     vehicleList(i,6)=sqrt((Load_length-Temp(1))^2+(Load_length-Temp(2))^2);
                        vehicleList(i,6)=max(abs(Load_length-Temp(1)),abs(Load_length-Temp(2)));
                        
                        vehRoute = traci.vehicle.getRoute(Vehicle_ID);
                        fromDir=vehRoute{1};
                        toDir=vehRoute{2};
                        switch fromDir(1)
                            case 'N'
                                vehicleList(i,7)=0;
                            case 'E'
                                vehicleList(i,7)=1;
                            case 'S'
                                vehicleList(i,7)=2;
                            case 'W'
                                vehicleList(i,7)=3;
                        end
                        switch toDir(1)
                            case 'N'
                                vehicleList(i,8)=0;
                            case 'E'
                                vehicleList(i,8)=1;
                            case 'S'
                                vehicleList(i,8)=2;
                            case 'W'
                                vehicleList(i,8)=3;
                        end
                        
                        
                        vehicleList(i,9) = traci.vehicle.getLaneIndex(Vehicle_ID);
                        vehTypeID = traci.vehicle.getTypeID(Vehicle_ID);
                        switch vehTypeID(5)
                            case 'L'
                                vehicleList(i,10)=2;
                            case 'F'
                                vehicleList(i,10)=1;
                            case 'R'
                                vehicleList(i,10)=0;
                        end
                        vehicleList;%1ID,2x,3y,4angle,5speed,6distance,7from,8to,9self lane,10turn,11self layer,12goal layer,13goal lane
                    end
                    
                    vehicleList=sortrows(vehicleList,1);
                    
                end
            end
            
            
            TT=10;
            if floor((step+1)/TT)~=floor(step/TT) || step==1
                
                if isempty(vehicleIDList)==0
                    
                    for i=1:vehicleIDListNum
                        vehicleList(i,11)=vehicleList(i,6);
                        trafficFlow1=vehicleList(i,7)*9+vehicleList(i,10)*3+vehicleList(i,9)+1;
                        slowFlag=0;
                        minGap=500;
                        for j=1:i
                            trafficFlow2=vehicleList(j,7)*9+vehicleList(j,10)*3+vehicleList(j,9)+1;
                            if i~=j && conflictMap(trafficFlow1,trafficFlow2)==1 && vehicleList(i,6)-vehicleList(j,11)<35
                                if vehicleList(j,6)+35>vehicleList(i,11)
                                    vehicleList(i,11)=vehicleList(j,6)+35;
                                end
                            end
                        end
                        vehicleID=num2str(vehicleList(i,1));
                        vehLaneIndex=traci.vehicle.getLaneIndex(vehicleID);
                        traci.vehicle.changeLane(vehicleID,vehLaneIndex,2);
                        if vehicleList(i,11)>vehicleList(i,6)
                            goalSpeed=15-0.5*(vehicleList(i,11)-vehicleList(i,6))-2;
                        else
                            goalSpeed=15;
                        end
                        
                        if goalSpeed<0
                            goalSpeed=0;
                        end
                        
                        if vehicleList(i,6)<50
                            goalSpeed=10;
                        end
                        
                        traci.vehicle.setSpeed(vehicleID,goalSpeed);
                    end
                    vehicleList1=vehicleList;
                end
                
                
            end
            
            
            
            
            
            
            
            
            TT=1;
            if floor((step+1)/TT)~=floor(step/TT) || step==1
                
                
                if isempty(vehicleIDList)==0
                    
                    
                    
                    for iii=1:vehicleIDListNum
                        vehicleID=num2str(vehicleList(iii,1));
                        Temp = traci.vehicle.getPosition(vehicleID);
                        xTemp=Temp(1);
                        yTemp=Temp(2);
                        
                        if Load_length-15<xTemp && xTemp<Load_length+15 && Load_length-15<yTemp && yTemp<Load_length+15
                            deleteSet=[deleteSet,vehicleList(iii,1)];
                            
                            traci.vehicle.setSpeedMode(vehicleID,0);%7
                            traci.vehicle.setSpeed(vehicleID,vF);%7
                            traci.vehicle.setLaneChangeMode(vehicleID,512);
                        end
                    end
                    
                    
                end
            end
            
            
            if vehicleGenerateCount>0 && isempty(vehicleIDList)==1 && step>T*10*3
                vehicleIDList
                resultTime=[resultTime,step];
                break
            end
            
            
            
            vehicleIDListTemp = traci.vehicle.getIDList();
            vehicleIDList={};
            if isempty(vehicleIDListTemp)==0
                for i=1:length(vehicleIDListTemp)
                    vehicleIDList=[vehicleIDList,vehicleIDListTemp{i}];
                end
            end
            if isempty(vehicleIDList)==0
                vehicleIDListNum=length(vehicleIDList);
                vehicleList=zeros(vehicleIDListNum,15);
                
                for i=1:vehicleIDListNum
                    vehicleList(i,1)=str2double(vehicleIDList{i});
                    Vehicle_ID=vehicleIDList{i};
                    Temp = traci.vehicle.getPosition(Vehicle_ID);
                    vehicleList(i,2)=Temp(1);
                    vehicleList(i,3)=Temp(2);
                    vehicleList(i,4)=traci.vehicle.getAngle(Vehicle_ID);
                    vehicleList(i,5)=traci.vehicle.getSpeed(Vehicle_ID);
                    vehicleList(i,6)=max(abs(Load_length-Temp(1)),abs(Load_length-Temp(2)));
                    vehRoute = traci.vehicle.getRoute(Vehicle_ID);
                    fromDir=vehRoute{1};
                    toDir=vehRoute{2};
                    switch fromDir(1)
                        case 'N'
                            vehicleList(i,7)=0;
                        case 'E'
                            vehicleList(i,7)=1;
                        case 'S'
                            vehicleList(i,7)=2;
                        case 'W'
                            vehicleList(i,7)=3;
                    end
                    switch toDir(1)
                        case 'N'
                            vehicleList(i,8)=0;
                        case 'E'
                            vehicleList(i,8)=1;
                        case 'S'
                            vehicleList(i,8)=2;
                        case 'W'
                            vehicleList(i,8)=3;
                    end
                    
                    vehicleList(i,9) = traci.vehicle.getLaneIndex(Vehicle_ID);
                    vehTypeID = traci.vehicle.getTypeID(Vehicle_ID);
                    switch vehTypeID(5)
                        case 'L'
                            vehicleList(i,10)=2;
                        case 'F'
                            vehicleList(i,10)=1;
                        case 'R'
                            vehicleList(i,10)=0;
                    end
                    vehicleList;%1ID,2x,3y,4angle,5speed,6distance,7from,8to,9self lane,10turn,11self layer,12goal layer,13goal lane
                    
                    
                    
                end
                
                vehicleList=sortrows(vehicleList,1);
            end
            vehicleState=[vehicleState,{vehicleList}];
            
            pause(0.001)
            
            %%
            
            if drawFigure==1||drawFigure==2
                
                
                if drawFigure==1
                    axis equal
                    
                    axisVector1=[0 Load_length 1300 1550];
                    axisVector2=[10 700 Load_length-200 Load_length+50];
                    axisVector3=[0 300 Load_length-105 Load_length+20];
                    axisVector4=[Load_length-Ring5-50 Load_length-Ring5+350 Load_length-105 Load_length+20];
                    axisVector5=[Load_length-300 Load_length Load_length-120 Load_length+20];
                    axisVector6=[Load_length-500 Load_length Load_length-120 Load_length+20];
                    
                    axisVector=axisVector4;
                    
                    x1=axisVector(1);
                    x2=axisVector(2);
                    y1=axisVector(3);
                    y2=axisVector(4);
                    
                    
                    
                    axis([x1 x2 y1 y2]);
                    grid minor
                    h=Load_length-15;
                    text(x1+10,h,'WEST','Color','k','fontsize',20);
                    text(x1+10,h-roadGap,'SOUTH','Color','k','fontsize',20);
                    text(x1+10,h-2*roadGap,'EAST','Color','k','fontsize',20);
                    text(x1+10,h-3*roadGap,'NORTH','Color','k','fontsize',20);
                    
                    text(x1+10,h+30,'Time=','Color','k','fontsize',20);
                    temp=num2str(step*simulation_step);
                    text(x1+50,h+30,temp,'Color','k','fontsize',20);
                    
                else
                    
                    num=length(All_Vehicle_List);
                    for i=1:num
                        
                        vehicleID=All_Vehicle_List{i};
                        vehPosition = traci.vehicle.getPosition(vehicleID);
                        vehAngle = traci.vehicle.getAngle(vehicleID);
                        
                        vehicle=[vehPosition(1),vehPosition(2),vehAngle];
                        if vehicleID(3)=='L'
                            [draw] = drawCar(vehicle,[1,0.72,0]);
                        elseif vehicleID(3)=='F'
                            [draw] = drawCar(vehicle,'r');
                        elseif vehicleID(3)=='R'
                            [draw] = drawCar(vehicle,[0,0.69,0.31]);
                        end
                    end
                    
                    
                    axis equal
                    grid minor
                    h=180;
                    axisVector=[Load_length-h Load_length+h Load_length-h Load_length+h];
                    
                    x1=axisVector(1);
                    x2=axisVector(2);
                    y1=axisVector(3);
                    y2=axisVector(4);
                    
                    axis([x1 x2 y1 y2]);
                    
                    text(x1+10,y2-50,'Time=','Color','k','fontsize',20);
                    temp=num2str(step*simulation_step);
                    text(x1+50,y2-50,temp,'Color','k','fontsize',20);
                    
                    %                     vehicle=[(x1+x2)/2+40,y2-50,90];
                    %                     [draw] = drawCarBig(vehicle,'y');
                    %                     text((x1+x2)/2+40,y2-80,'Turn left','Color','k','fontsize',15);
                    %
                    %                     vehicle=[(x1+x2)/2+120,y2-50,90];
                    %                     [draw] = drawCarBig(vehicle,'r');
                    %                     text((x1+x2)/2+120,y2-80,'Go straight','Color','k','fontsize',15);
                    %
                    %                     vehicle=[(x1+x2)/2+200,y2-50,90];
                    %                     [draw] = drawCarBig(vehicle,'g');
                    %                     text((x1+x2)/2+200,y2-80,'Turn right','Color','k','fontsize',15);
                    
                end
                
                
                set(gcf,'Units','centimeters','Position',[2 2 32 20]);
                set(gcf,'Units','centimeters','Position',[1 1 26 26]);
                set(gcf,'Units','centimeters','Position',[1 1 40 26]);
                set(gca,'position',[0.05,0.05,0.9,0.9]);
                f=getframe(gcf);
                str0='C:\MatlabImage\20Multi\';
                str1=num2str(step);
                str2='.jpg';
                save_path=[str0,str1,str2];
                imwrite(f.cdata,save_path);
            end
            
            
            
            %             pause(0.1)
        end
        
        
        
        traci.close()
        
        save([nameTemp,'_3_ResultREF_',num2str(suijishu),'_',num2str(liuliang),'_',num2str(bili),'.mat'],'vehicleState')
        
    end
end
