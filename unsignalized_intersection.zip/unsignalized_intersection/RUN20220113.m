clear
close all
clc

testTemp=[];

drawFigure=0;

nameTemp=[num2str(year(now)),'-',num2str(month(now)),'-',num2str(day(now)),'-',num2str(hour(now)),'-',num2str(minute(now)),'-',num2str(second(now)*1000)]

turningRatioSet=[0.33,0.66,1;
    0.5,0.75,1;
    0.25,0.75,1;
    0.25,0.5,1];
TflowSet1=[1000,2000,3000,4000,5000,6000];
TflowSet=TflowSet1/3600/10;



resultTimeSet=[];

for suijishu=4:50
    for liuliang=5:5
        for bili=1:4
        
            testVehicleNum=TflowSet1(liuliang)/4;
            resultTime=[];
            
            rand('seed',suijishu*1000);
            turningRatio=turningRatioSet(bili,:);
            Tflow=TflowSet(liuliang);
            layerModeNum=1;
            Main20210709;       
            
%             rand('seed',suijishu*1000);
%             turningRatio=turningRatioSet(bili,:);
%             Tflow=TflowSet(liuliang);
%             layerModeNum=2;
%             Main20210709;
%             
%             rand('seed',suijishu*1000);
%             turningRatio=turningRatioSet(bili,:);
%             Tflow=TflowSet(liuliang);
%             layerModeNum=3;
%             Main20210709trafficLight; 
            
            
        end
    end
end