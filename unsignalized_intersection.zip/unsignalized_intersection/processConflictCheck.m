function result = processConflictCheck(x1,y1,x2,y2,xx1,yy1,xx2,yy2)
result=0;
if xx1==x1 && yy1==y2 && xx2==x1 && yy2==y2
    result=1;
elseif xx1==x2 && yy1==y1 && xx2==x2 && yy2==y1
    result=1;
elseif xx1==x2 && yy1==y1 && xx2==x1 && yy2==y1
    result=1;
elseif xx1==x1 && yy1==y2 && xx2==x1 && yy2==y1
    result=1;
elseif xx1==x2 && yy1==y2 && xx2==x2 && yy2==y1
    result=1;
elseif xx1==x2 && yy1==y2 && xx2==x1 && yy2==y2
    result=1;
end


end

