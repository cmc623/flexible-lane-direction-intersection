function result = IsBarrierEdge(barrierEdges,state,direction)
result=0;
if isempty(barrierEdges)==1
    result=0;
else
    barrierNum=length(barrierEdges(:,1));
    for i=1:barrierNum
        if state(1)==barrierEdges(i,1) && state(2)==barrierEdges(i,2) && state(3)==barrierEdges(i,3) && direction(1)==barrierEdges(i,4) && direction(2)==barrierEdges(i,5) && direction(3)==barrierEdges(i,6)
            result=1;
            break
        end
    end
end



