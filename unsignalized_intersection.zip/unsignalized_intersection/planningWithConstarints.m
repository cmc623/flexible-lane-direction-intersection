function [paths,closeCC,lengthCount] = planningWithConstarints(vehicles,targets,nodeConstraints,edgeConstraints)
closeCC=0;
paths=[];
vehicleNum=length(vehicles(:,1));
if isempty(nodeConstraints)==0
    nodeConstraintsNum=length(nodeConstraints(:,1));
else
    nodeConstraintsNum=0;
end

if isempty(edgeConstraints)==0
    edgeConstraintsNum=length(edgeConstraints(:,1));
else
    edgeConstraintsNum=0;
end

for i=1:vehicleNum
    
    pathSingle=[];
    
    nodeConstraintsVehicle=[];
    edgeConstraintsVehicle=[];
    
    for j=1:nodeConstraintsNum
        if nodeConstraints(j,4)==i
            nodeConstraintsVehicle=[nodeConstraintsVehicle;nodeConstraints(j,1),nodeConstraints(j,2),nodeConstraints(j,3)];
        end
    end
    
    for j=1:edgeConstraintsNum
        if edgeConstraints(j,7)==i
            edgeConstraintsVehicle=[edgeConstraintsVehicle;edgeConstraints(j,1),edgeConstraints(j,2),edgeConstraints(j,3),edgeConstraints(j,4),edgeConstraints(j,5),edgeConstraints(j,6)];
        end
    end
    
    Map=zeros(max(max(vehicles(:,1)),max(targets(:,1)))*3+5,3);
    Map(vehicles(i,1),vehicles(i,2))=5;%���λ��
    
    vehicles;
    targets;
    Map;
    
    if Map(targets(i,1),targets(i,2))==5
        Map(targets(i,1),targets(i,2))=7;%Ŀ��λ��
    else
        Map(targets(i,1),targets(i,2))=2;%Ŀ��λ��
    end
    
    
    [~,closeC]=Astar3D(Map,nodeConstraintsVehicle,edgeConstraintsVehicle);
    
    if i==4
        closeCC=closeC;
    end
    
    vehicleX=[closeC.x];
    vehicleY=[closeC.y];
    vehicleT=[closeC.t];
    vehicleFX=[closeC.fx];
    vehicleFY=[closeC.fy];
    vehicleFT=[closeC.ft];
    
    numTemp=length(vehicleX);
    
    endX=vehicleX(numTemp);
    endY=vehicleY(numTemp);
    endT=vehicleT(numTemp);
    
    fX=vehicleFX(numTemp);
    fY=vehicleFY(numTemp);
    fT=vehicleFT(numTemp);
    
    pathSingle=[endX,endY,endT];
    
    while(fX~=vehicleX(1)||fY~=vehicleY(1)||fT~=vehicleT(1))
        if vehicleFX<0
            break
        end
        for j=1:numTemp
            if vehicleX(j)==fX && vehicleY(j)==fY && vehicleT(j)==fT
                pathSingle=[fX,fY,fT;pathSingle];
                fX=vehicleFX(j);
                fY=vehicleFY(j);
                fT=vehicleFT(j);
                break
            end
        end
    end
    
    if endX~=vehicleX(1) || endY~=vehicleY(1) || endT~=vehicleT(1)
        pathSingle=[vehicleX(1),vehicleY(1),vehicleT(1);pathSingle];
    end
    
    if pathSingle(1)==-1
        pathSingle(1)=vehicles(i,1);
        pathSingle(2)=vehicles(i,2);
        pathSingle(3)=1;
    end
    
    paths=[paths;{pathSingle(:,1:2),length(pathSingle(:,1))}];
    
end

maxLength=max(cell2mat(paths(:,2)));
lengthCount=0;

for i=1:vehicleNum
%     paths;
%     aaaaa=paths{i,1}
%     lengthCount=lengthCount+paths{i,2};
    
    pathTemp=paths{i,1};
    for j=paths{i,2}:(-1):1
        if pathTemp(j,1)~=pathTemp(paths{i,2},1) || pathTemp(j,2)~=pathTemp(paths{i,2},2)
            lengthCount=lengthCount+(j);
            break
        end
        
    end
    
    if paths{i,2}<maxLength
        
        for j=(paths{i,2}+1):maxLength
            iterateTemp=paths{i,1};
            paths{i,1}=[paths{i,1};iterateTemp(length(iterateTemp(:,1)),:)];
        end
        
        paths{i,2}=maxLength;
    end
end


end

