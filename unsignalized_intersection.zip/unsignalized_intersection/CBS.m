function [paths,answer]=CBS(vehiclesAssign,assignSort)

vehicles=vehiclesAssign;
targets=assignSort;

global constraintTree edgeConstraints nodeConstraints
CBSmain