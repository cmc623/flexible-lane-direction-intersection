function [draw] = drawCar(Car,CarColor)

CarLength=-4;
CarX=Car(1);
CarY=Car(2);
CarDir=Car(3);

CarHeadX=CarX+CarLength*sind(CarDir);
CarHeadY=CarY+CarLength*cosd(CarDir);


plot([CarHeadX,CarX],[CarHeadY,CarY],'Color',CarColor,'LineWidth',2)


% plot(CarX,CarY,'.','Color','r','MarkerSize',10)


% plot([CarHeadX,CarX],[CarHeadY,CarY],'LineWidth',5)
hold on
% plot(CarX,CarY,'.','Color','b','MarkerSize',35)
hold on
% plot(CarHeadX,CarHeadY,'.','Color','r','MarkerSize',20)
hold on

draw=1;
end

