function result = IsBarrier(barriers,state)
result=0;
if isempty(barriers)==1
    result=0;
else
    barrierNum=length(barriers(:,1));
    for i=1:barrierNum
        if state(1)==barriers(i,1) && state(2)==barriers(i,2) && state(3)==barriers(i,3)
            result=1;
            break
        end
    end
end



