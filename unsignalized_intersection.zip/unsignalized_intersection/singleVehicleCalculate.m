function [solution,totalPointList,goals] = singleVehicleCalculate(pathRelativeI,vF,T,Gap,vehicle,p0,coordinates)

global laneWidth
% pathRelativeI
disp('singleVehicleCalculate')
phaseTimes=length(pathRelativeI(:,1))

goals=zeros(phaseTimes+1,6);

% coordinates
% laneWidth
% goals(1,:)=vehicle;
goals(1,1)=p0-(coordinates(1,1)-1)*Gap;
goals(1,2)=coordinates(1,2)*laneWidth;

for i=2:phaseTimes+1
    goals(i,1)=goals(i-1,1)+vF*T-pathRelativeI(i-1,1)*Gap;
    goals(i,2)=goals(i-1,2)+pathRelativeI(i-1,2)*laneWidth;
end

for i=1:phaseTimes
    goals(i,3)=90-atan(2*(goals(i+1,2)-goals(i,2))/(goals(i+1,1)-goals(i,1)+0.001))/3.14*180;
end
goals(phaseTimes+1,3)=90;
% vehicle
goals(1,:)=vehicle;




distanceCurve=zeros(phaseTimes,1);

totalPointList=[];

for i=1:phaseTimes
    if i==1
        [pointList,~]=trajectory_planning(vehicle,goals(i+1,:),vF*T);
    else
        [pointList,~]=trajectory_planning(goals(i,:),goals(i+1,:),vF*T);
    end
    traj=pointList;
%     pointList1=pointList;
%     plot(pointList1(:,1),pointList1(:,2))
    totalPointList=[totalPointList;pointList];
    
    n=length(traj(:,1));
    distanceCurve(i,1)=0;
    for j=1:n-1
        distance00=sqrt((traj(j+1,1)-traj(j,1))^2+(traj(j+1,2)-traj(j,2))^2);
        distanceCurve(i,1)=distanceCurve(i,1)+distance00;
    end
    
end

% distanceCurve



% hold on
% plot(totalPointList(:,1),totalPointList(:,2))





amin=-10;
amax=5;
vmin=0;
vmax=20;

setup.name = 'BrysonDenham';

setup.functions.continuous = @BrysonDenhamContinuous;
setup.functions.endpoint = @BrysonDenhamEvents;

setup.nlp.solver = 'snopt';
setup.derivatives.supplier = 'sparseCD';
setup.derivatives.derivativelevel = 'second';
%setup.scales.method = 'automatic-bounds';

setup.method = 'RPMintegration';

setup.mesh.method = 'hp';
setup.mesh.tolerance = 1e-1; % default 1e-3

N = 2;



for i=1:phaseTimes
    setup.mesh.phase(i).colpoints = 4*ones(1,N);
    setup.mesh.phase(i).fraction   = ones(1,N)/N;
end
setup.mesh
%--Problem Setup--
%state 1

for i=1:phaseTimes
    
    if phaseTimes==1
        disp('phaseTimes==1')
        x10 = 0;
        x1f = distanceCurve(1,1);
        x1min = 0;
        x1max = x1f;
        
        x20 = vehicle(4);
        x2f = vF;
        x2min = vmin;
        x2max = vmax;
        
        x30 = 0;
        x3min = -100000;
        x3max = 100000;
        
        umin = amin;
        umax = amax;
        
        t0 = 0;
        tf = T;
        
        x1_guess = [x10; x1f];
        x2_guess = [x2min; x2max];
        x3_guess = [x30; x3max];
        
        u_guess = [umin;umax];
        t_guess = [t0; tf];
        
        setup.bounds.phase(i).initialstate.lower = [x10, x20, x30];
        setup.bounds.phase(i).initialstate.upper = [x10, x20, x30];
        setup.bounds.phase(i).state.lower = [x1min, x2min, x3min];
        setup.bounds.phase(i).state.upper = [x1max, x2max, x3max];
        setup.bounds.phase(i).finalstate.lower = [x1f, x2f, x3min];
        setup.bounds.phase(i).finalstate.upper = [x1f, x2f, x3max];
        
        setup.bounds.phase(i).control.lower = [umin];
        setup.bounds.phase(i).control.upper = [umax];
        
        setup.bounds.phase(i).initialtime.lower = t0;
        setup.bounds.phase(i).initialtime.upper = t0;
        
        setup.bounds.phase(i).finaltime.lower = tf;
        setup.bounds.phase(i).finaltime.upper = tf;
        
        setup.guess.phase(i).state = [x1_guess, x2_guess, x3_guess];
        setup.guess.phase(i).control = u_guess;
        setup.guess.phase(i).time = t_guess;
        
        
    else
        if i==1
%             disp('i==1')
            x10 = 0;
            x1f = distanceCurve(1,1);
            x1min = 0;
            x1max = x1f;
            
            x20 = vehicle(4);
            %x2f = vF;
            x2min = vmin;
            x2max = vmax;
            
            x30 = 0;
            x3min = -100000;
            x3max = 100000;
            
            umin = amin;
            umax = amax;
            
            t0 = 0;
            tf = T;
            
            x1_guess = [x10; x1f];
            x2_guess = [x2min; x2max];
            x3_guess = [x30; x3max];
            
            u_guess = [umin;umax];
            t_guess = [t0; tf];
            
            setup.bounds.phase(i).initialstate.lower = [x10, x20, x30];
            setup.bounds.phase(i).initialstate.upper = [x10, x20, x30];
            setup.bounds.phase(i).state.lower = [x1min, x2min, x3min];
            setup.bounds.phase(i).state.upper = [x1max, x2max, x3max];
            setup.bounds.phase(i).finalstate.lower = [x1f, x2min, x3min];
            setup.bounds.phase(i).finalstate.upper = [x1f, x2max, x3max];
            
            setup.bounds.phase(i).control.lower = [umin];
            setup.bounds.phase(i).control.upper = [umax];
            
            setup.bounds.phase(i).initialtime.lower = t0;
            setup.bounds.phase(i).initialtime.upper = t0;
            
            setup.bounds.phase(i).finaltime.lower = tf;
            setup.bounds.phase(i).finaltime.upper = tf;
            
            setup.guess.phase(i).state = [x1_guess, x2_guess, x3_guess];
            setup.guess.phase(i).control = u_guess;
            setup.guess.phase(i).time = t_guess;
        elseif i==phaseTimes
%             disp('i==phaseTimes')
            x10 = sum(distanceCurve(:,1))-distanceCurve(phaseTimes,1);
            x1f = sum(distanceCurve(:,1));
            x1min = 0;
            x1max = x1f;
            
            %x20 = vF;
            x2f = vF;
            x2min = vmin;
            x2max = vmax;
            
            x30 = 0;
            x3min = -100000;
            x3max = 100000;
            
            umin = amin;
            umax = amax;
            
            t0 = T*(phaseTimes-1);
            tf = T*phaseTimes;
            
            x1_guess = [x10; x1f];
            x2_guess = [x2min; x2max];
            x3_guess = [x30; x3max];
            
            u_guess = [umin;umax];
            t_guess = [t0; tf];
            
            setup.bounds.phase(i).initialstate.lower = [x10, x2min, x30];
            setup.bounds.phase(i).initialstate.upper = [x10, x2max, x30];
            setup.bounds.phase(i).state.lower = [x1min, x2min, x3min];
            setup.bounds.phase(i).state.upper = [x1max, x2max, x3max];
            setup.bounds.phase(i).finalstate.lower = [x1f, x2f, x3min];
            setup.bounds.phase(i).finalstate.upper = [x1f, x2f, x3max];
            
            setup.bounds.phase(i).control.lower = [umin];
            setup.bounds.phase(i).control.upper = [umax];
            
            setup.bounds.phase(i).initialtime.lower = t0;
            setup.bounds.phase(i).initialtime.upper = t0;
            
            setup.bounds.phase(i).finaltime.lower = tf;
            setup.bounds.phase(i).finaltime.upper = tf;
            
            setup.guess.phase(i).state = [x1_guess, x2_guess, x3_guess];
            setup.guess.phase(i).control = u_guess;
            setup.guess.phase(i).time = t_guess;
        else
%             disp('else')
            x10 = sum(distanceCurve(1:i-1,1));
            x1f = sum(distanceCurve(1:i,1));
            x1min = 0;
            x1max = x1f;
            
            %x20 = vF;
            %x2f = vF;
            x2min = vmin;
            x2max = vmax;
            
            x30 = 0;
            x3min = -100000;
            x3max = 100000;
            
            umin = amin;
            umax = amax;
            
            t0 = T*(i-1);
            tf = T*i;
            
            x1_guess = [x10; x1f];
            x2_guess = [x2min; x2max];
            x3_guess = [x30; x3max];
            
            u_guess = [umin;umax];
            t_guess = [t0; tf];
            
            setup.bounds.phase(i).initialstate.lower = [x10, x2min, x30];
            setup.bounds.phase(i).initialstate.upper = [x10, x2max, x30];
            setup.bounds.phase(i).state.lower = [x1min, x2min, x3min];
            setup.bounds.phase(i).state.upper = [x1max, x2max, x3max];
            setup.bounds.phase(i).finalstate.lower = [x1f, x2min, x3min];
            setup.bounds.phase(i).finalstate.upper = [x1f, x2max, x3max];
            
            setup.bounds.phase(i).control.lower = [umin];
            setup.bounds.phase(i).control.upper = [umax];
            
            setup.bounds.phase(i).initialtime.lower = t0;
            setup.bounds.phase(i).initialtime.upper = t0;
            
            setup.bounds.phase(i).finaltime.lower = tf;
            setup.bounds.phase(i).finaltime.upper = tf;
            
            setup.guess.phase(i).state = [x1_guess, x2_guess, x3_guess];
            setup.guess.phase(i).control = u_guess;
            setup.guess.phase(i).time = t_guess;
        end
        
    end
    
end

for i=1:phaseTimes-1
    setup.bounds.eventgroup(i).lower = 0;
    setup.bounds.eventgroup(i).upper = 0;
end

%--Call the Solver--
%probinfo = gpopsProblemInfo(setup);

output = gpops2(setup);

solution = output.result.solution;

% figure(1)
% for j=1:phaseTimes
%     plot(solution.phase(j).time,solution.phase(j).state(:,1),'-o', 'markersize', 2, 'linewidth', 1.5);
%     hold on
%     grid on
% end
% 
% figure(2)
% for j=1:phaseTimes
%     plot(solution.phase(j).time,solution.phase(j).state(:,2),'-o', 'markersize', 2, 'linewidth', 1.5);
%     hold on
%     grid on
% end
% 
% figure(3)
% for j=1:phaseTimes
%     plot(solution.phase(j).time,solution.phase(j).control,'-o', 'markersize', 2, 'linewidth', 1.5);
%     hold on
%     grid on
% end

end