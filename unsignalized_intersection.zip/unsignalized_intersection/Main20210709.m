
% rng('shuffle');



conflictMap=[
    1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 0 0 0 0 0 0
    0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0  0 0 0 0 0 0 1 1 0  0 0 0 0 0 0 0 0 0
    0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0  0 0 0 0 0 0 1 1 1  0 0 0 0 0 0 0 0 0
    0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0  0 0 0 0 0 0 1 1 1  1 1 1 1 1 1 1 1 1
    0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0  0 0 0 0 0 0 1 1 1  0 1 1 1 1 1 1 1 1
    0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1  0 0 0 0 0 0 1 1 1  0 0 1 1 1 1 1 1 1
    0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1  1 1 1 1 1 1 1 1 1  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1  0 1 1 1 1 1 1 1 1  0 0 0 0 1 1 1 1 1
    0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1  0 0 1 1 1 1 1 1 0  0 0 0 0 0 1 1 1 1
    
    0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0  0 0 0 0 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0  0 0 0 0 0 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1  0 0 0 0 0 0 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1  1 1 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1  0 1 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1  0 0 1 1 1 1 1 1 0
    
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0  0 0 0 1 0 0 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0  0 0 0 1 1 0 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1  0 0 0 1 1 1 0 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0  0 0 0 1 1 1 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0  0 0 0 1 1 1 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0  0 0 0 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1  0 0 0 1 1 1 1 1 1
    
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  1 0 0 1 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 1 0 1 1 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 1 1 1 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 1 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 1 0 1 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 1 1 1 1
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 1 0 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 1 0
    0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1
    ];

conflictMapNum=length(conflictMap(1,:));
for i=1:conflictMapNum
    for j=i+1:conflictMapNum
        conflictMap(j,i)=conflictMap(i,j);
    end
end

answer={0,0,0,0,0,0};

global Acc_Speed_Count
global Count_all
Count_all=[0,0,0,0,1];
for tflow_i = 1:length(Tflow)
    disp('Multi');
    tflow_i
    Last_Error={'aaa',1};
    %% Output defination
    % CAV_List:
    % Col_1         Col_2       Col_3           Col_4       Col_5
    % Vehicle_ID    Status      Control_Step    solution    Control_Time
    % Col_6             Col_7                   Col_8
    % Control_Speed     Pass_vehicle    Time_to_Trafficlight
    % Col_9                 Col_10
    % Target_Green_Start
    
    % Data_record
    % Col_1         Col_2           Col_3               Col_4           Col_5
    % vehicle_ID    vehicle_Type    Vehicle_Position    Vehicle_Speed   Fuel_Consumotion
    
    %% Path
    simulation_step = 0.1;
    
    simulation_folder = 'traci_tls\data';
    scenarioPath = fullfile(simulation_folder,'cross.sumocfg');
    routePath = fullfile(simulation_folder,'cross.rou.xml');
    nodPath = fullfile(simulation_folder,'cross.nod.xml');
    edgePath = fullfile(simulation_folder,'cross.edg.xml');
    connPath = fullfile(simulation_folder,'cross.con.xml');
    sumoHome = getenv('SUMO_HOME');
    
    %% Flags
    SUMO_GUI = 'true';
    
    %% Parameters
    Penetration_Rate = 0.9;
    Total_Simulation_Vehicle = 300;
    Test_Speed = 10;
    Test_Platoon_Size = 9;
    
    % Vehicle_Per_Hour = 800;
    % Test_Depart_Gap = 1./(Vehicle_Per_Hour / 3600);
    % Test_Depart_Gap = floor(Test_Depart_Gap * 10)/10;
    
    Test_Depart_Gap = 5.1;
    
    % Depart_Gap = 5; %s
    intersection_offset = 8.55;
    RegularPlatoonSize = 10;
    Min_Gap = 2;
    Reaction_Time = 1;
    Vehicle_length = 4;
    Max_speed = 14.66;
    Simulation_Total_Time = 0;
    Min_acc = -6;
    Max_acc = 3;
    
    Load_length = 400;
    Load_length2 = 600;
    
    
    Ring1=15;
    Ring2=300;
    Ring3=300;%����
    Ring4=500;
    Ring5=700;
    Ring6=950;
    
    vehicle_Gap=30;%�����ڵĸ������
    
    All_Intersection_direction = {'E_L','E_F','E_R','S_L','S_F','S_R','W_L','W_F','W_R','N_L','N_F','N_R'};%F��ʾforward
    All_Leg = {'W','S','E','N'};
    All_Direction = {'L','F','R'};
    
    Vehicle_List1={};
    Vehicle_List2={};
    Vehicle_List3={};
    Vehicle_List4={};
    
    Vehicle_List=cell(1,4);
    All_Vehicle_List={};
    
    All_Route=cell(4,3);
    
    All_Route(1,1)={['West','_in_','North','_out']};
    All_Route(1,2)={['West','_in_','East','_out']};
    All_Route(1,3)={['West','_in_','South','_out']};
    
    All_Route(2,1)={['South','_in_','West','_out']};
    All_Route(2,2)={['South','_in_','North','_out']};
    All_Route(2,3)={['South','_in_','East','_out']};
    
    All_Route(3,1)={['East','_in_','South','_out']};
    All_Route(3,2)={['East','_in_','West','_out']};
    All_Route(3,3)={['East','_in_','North','_out']};
    
    All_Route(4,1)={['North','_in_','East','_out']};
    All_Route(4,2)={['North','_in_','South','_out']};
    All_Route(4,3)={['North','_in_','West','_out']};
    
    save Parameter.mat
    tic
    New_Connections1();
    New_Road();
    New_Edge();
    New_Vehicle();
    
    
    vehicleNum=4;
    
    speedCount={'aaa',0,0};
    roadGap=30;
    
    accCount={'aaa',0,0,0,0};
    vehicleYES=0;
    
    vehicleGroupsLayer={};
    
    
    Acc_Speed_Count={'aaa',1,1,1,1,1,1};
    
    global X1 X2 X3 vF T laneWidth dt gap
    X1=0;
    X2=1000;
    X3=1200;
    vF=10;
    T=4;
    laneWidth=3.3;
    dt=simulation_step;
    gap=17;
    
    vehicleGenerateCount=0;
    
    vehicleSpeedList=cell(1,4);
    vehicleChangeLaneList=cell(1,4);
    deleteSet=[];
    
    vehicleState={};
    vehicleList1=[121212];
    
    %% GUI SET COMMANDS
    
    for Simulation_Depart_Gap = 1:length(Test_Depart_Gap)
        Depart_Gap = Test_Depart_Gap(Simulation_Depart_Gap);
        ArriveTimePlan = [];
        save('Variables.mat','ArriveTimePlan')
        save Parameter.mat
        
        switch SUMO_GUI
            case 'true'
                %                 traci.start(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --start' ' --quit-on-end']);
                %                 system(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --lanechange.duration 1' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                system(['sumo-gui -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --lanechange.duration 2' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                traci.init();
                traci.gui.setSchema('View #0','real world');
            case 'false'
                %                 traci.start(['sumo-gui ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --start' ' --quit-on-end']);
                system(['sumo -c ' '"' scenarioPath '"' ' --step-length ' num2str(simulation_step) ' --remote-port 8873 --start' ' --tripinfo-output' ' "tripinfo.xml"' ' --quit-on-end&' ]);
                traci.init();
            otherwise
                continue;
        end
        
        %% Main
        
        step=0;
        
        
        
        while step <((1/simulation_step)*100000000)
            if step==0
                vehicleList=[];
                vehicleIDList={};
            end
            timeOut=0;
%             if step>3000
%                 timeOut=1;
%                 break
%             end
            
            step = step + 1;
            str12=num2str(step);
            %%%disp(str12);
            traci.simulationStep();
            %             disp('1121212121212121221')
            %             traci.trafficlights.setRedYellowGreenState('Center','OOOOOOOOOOOOOOOOOOOOO');
            %             disp('###################')
            
            
            if rand(1)<Tflow(tflow_i) && vehicleGenerateCount<testVehicleNum%�����³�
                vehicleGenerateCount=vehicleGenerateCount+1;
                temp1=rand(1);
                lane=floor(temp1*3);
                
                temp2=rand(1);
                if temp2<turningRatio(1)
                    temp2=1;
                elseif temp2<turningRatio(2)
                    temp2=2;
                else
                    temp2=3;
                end
                
                goal=All_Direction{temp2};
                
                vehicleYES=1;
                
                temp3=rand(1);
                fromDir=floor(temp3*4)+1;
                if fromDir==5
                    fromDir=4;
                end
                
                
                newVehicleID = [All_Leg{fromDir},'_',goal,'_',num2str(step)];
                
                newVehicleID=num2str(step);
                
                newVehicleRoute=All_Route{fromDir,ceil(temp2)};
                
                if goal=='L'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,3-temp2,'CAV_L');
                elseif goal=='F'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,3-temp2,'CAV_F');
                elseif goal=='R'
                    traci.vehicle.add(newVehicleID,newVehicleRoute,-3,0,vF,3-temp2,'CAV_R');
                end
                traci.vehicle.setSpeedMode(newVehicleID,31);%7
                traci.vehicle.setSpeed(newVehicleID,vF);%7
                traci.vehicle.setLaneChangeMode(newVehicleID,512);
                
                All_Vehicle_List=[All_Vehicle_List,newVehicleID];
                
                
            end
            
            
            
            
            
            
            TT=1;
            if floor((step+1)/TT)~=floor(step/TT) || step==1
                vehicleIDListTemp = traci.vehicle.getIDList();
                vehicleIDList={};
                
                
                
                if isempty(vehicleIDListTemp)==0
                    for i=1:length(vehicleIDListTemp)
                        if ismember(str2num(vehicleIDListTemp{i}),deleteSet)==0
                            vehicleIDList=[vehicleIDList,vehicleIDListTemp{i}];
                        end
                    end
                end
                
                
                if isempty(vehicleIDList)==0
                    vehicleIDListNum=length(vehicleIDList);
                    vehicleList=zeros(vehicleIDListNum,25);
                    
                    for i=1:vehicleIDListNum
                        vehicleList(i,1)=str2double(vehicleIDList{i});
                        Vehicle_ID=vehicleIDList{i};
                        Temp = traci.vehicle.getPosition(Vehicle_ID);
                        vehicleList(i,2)=Temp(1);
                        vehicleList(i,3)=Temp(2);
                        vehicleList(i,4)=traci.vehicle.getAngle(Vehicle_ID);
                        vehicleList(i,5)=traci.vehicle.getSpeed(Vehicle_ID);
                        %                     vehicleList(i,6)=sqrt((Load_length-Temp(1))^2+(Load_length-Temp(2))^2);
                        vehicleList(i,6)=max(abs(Load_length-Temp(1)),abs(Load_length-Temp(2)));
                        
                        vehRoute = traci.vehicle.getRoute(Vehicle_ID);
                        fromDir=vehRoute{1};
                        toDir=vehRoute{2};
                        switch fromDir(1)
                            case 'N'
                                vehicleList(i,7)=0;
                            case 'E'
                                vehicleList(i,7)=1;
                            case 'S'
                                vehicleList(i,7)=2;
                            case 'W'
                                vehicleList(i,7)=3;
                        end
                        switch toDir(1)
                            case 'N'
                                vehicleList(i,8)=0;
                            case 'E'
                                vehicleList(i,8)=1;
                            case 'S'
                                vehicleList(i,8)=2;
                            case 'W'
                                vehicleList(i,8)=3;
                        end
                        
                        vehicleList(i,9) = traci.vehicle.getLaneIndex(Vehicle_ID);
                        vehTypeID = traci.vehicle.getTypeID(Vehicle_ID);
                        switch vehTypeID(5)
                            case 'L'
                                vehicleList(i,10)=2;
                            case 'F'
                                vehicleList(i,10)=1;
                            case 'R'
                                vehicleList(i,10)=0;
                        end
                        vehicleList;%1ID,2x,3y,4angle,5speed,6distance,7from,8to,9self lane,10turn,11self layer,12goal layer,13goal lane
                        
                        
                        
                    end
                    
                    vehicleList=sortrows(vehicleList,1);
                    
                    while(1)
                        flag=0;
                        for i=1:vehicleIDListNum
                            for j=i:vehicleIDListNum
                                if vehicleList(i,7)==vehicleList(j,7) && vehicleList(i,10)==vehicleList(j,10) && i~=j && vehicleList(i,6)>vehicleList(j,6)
%                                 if vehicleList(i,7)==vehicleList(j,7) && i~=j && vehicleList(i,6)>vehicleList(j,6)
                                    flag=1;
                                    temp=vehicleList(i,:);
                                    vehicleList(i,:)=vehicleList(j,:);
                                    vehicleList(j,:)=temp;
                                end
                            end
                        end
                        if flag==0
                            break
                        end
                    end
                    
                end
            end
            
            
            TT=T*10;
            if floor((step+1)/TT)~=floor(step/TT) || step==1
                if isempty(vehicleIDList)==0
                    
                    MiniInterDistance=min(vehicleList(:,6));
                    
                    for i=1:vehicleIDListNum
                        if vehicleList(i,6)==MiniInterDistance
                            frontID=i;
                            break
                        end
                    end
                    
                    
                    
                    
                    flag=0;
                    if isempty(vehicleList1)==0
                        
                        for j=1:length(vehicleList1(:,1))
                            if vehicleList1(j,1)==vehicleList(frontID,1)
                                desireLayer=vehicleList1(j,12);
                                selfLayer=vehicleList1(j,11)+vehicleList1(j,14);
                                flag=1;
                            end
                        end
                    end
                    
                    if flag==1
                        if selfLayer<desireLayer
                            selfLayer=desireLayer;
                        end
                        MiniInterDistance=MiniInterDistance-(selfLayer-desireLayer)*gap;
                    else
                        accLayers=floor(vehicleList(frontID,6)/(vF*T+gap));
                        if accLayers<0
                            accLayers=0;
                        end
                        MiniInterDistance=MiniInterDistance-accLayers*gap;
                    end

                    
                    
                    for i=1:vehicleIDListNum
                        
                        aaaaa=round(abs(vehicleList(i,6)-MiniInterDistance)/gap)+1;
                        vehicleList(i,11)=aaaaa;
                        for j=1:i
                            if vehicleList(i,11)==vehicleList(j,11) && vehicleList(i,9)==vehicleList(j,9) && vehicleList(i,7)==vehicleList(j,7) && j~=i
                                vehicleList(i,11)=vehicleList(i,11)+1;
                            end
                        end
                        
                    end
                    
                    while(1)
                        flag=0;
                        for i=1:vehicleIDListNum
                            for j=1:i
                                if vehicleList(i,11)==vehicleList(j,11) && vehicleList(i,9)==vehicleList(j,9) && vehicleList(i,7)==vehicleList(j,7) && j~=i
                                    vehicleList(i,11)=vehicleList(i,11)+1;
                                    flag=1;
                                end
                            end
                        end
                        if flag==0
                            break
                        end
                    end
                    
                    
                    
                    for i=1:vehicleIDListNum
                        accLayers=floor(vehicleList(i,6)/(vF*T+gap))-2;
                        if accLayers<0
                            accLayers=0;
                        end
                        
                        %                         if vehicleList(i,6)<70
                        %                             accLayers=0;
                        %                         end
                        
                        waitLayer=0;
                        if vehicleList(i,5)<5
                            waitLayer=1;
                        end
                        vehicleList(i,16)=vehicleList(i,11)-accLayers+waitLayer;
                    end
                    
                    layerCheck=1;
                    layerAdd=1;
                    
                    while(1)
                        thisLayer=[];
                        thisLayerID=[];
                        for i=1:vehicleIDListNum
                            
                            
                            
                            if vehicleList(i,16)<=layerCheck && vehicleList(i,17)==0
                                
                                
                                flag1=0;
                                [distribution,flag1]=layerCalculate([thisLayer,i],conflictMap,vehicleList,layerModeNum,[thisLayerID,vehicleList(i,1)]);
                                if flag1==1
                                    
                                    layerAdd=2;
                                    vehicleList(i,12)=layerCheck;
                                    vehicleList(i,17)=1;
                                    thisLayer=[thisLayer,i];
                                    thisLayerID=[thisLayerID,vehicleList(i,1)];
                                    for j=1:length(thisLayer)
                                        if length(thisLayer)==1 && vehicleList(thisLayer(j),10)==2
                                            distribution(j,1)=2;
                                        end
                                        vehicleList(thisLayer(j),13)=distribution(j,1);
                                    end
                                
                                end
                            end
                            
                        end
                        layerCheck=layerCheck+layerAdd;
                        if min(vehicleList(:,17))==1
                            break
                        end
                    end
                end
                vehicleList1=vehicleList;
                
                
                
                VehicleListArm=cell(1,4);
                
                if isempty(vehicleIDList)==0
                    for i=1:vehicleIDListNum
                        VehicleListArm{vehicleList(i,7)+1}=[VehicleListArm{vehicleList(i,7)+1};vehicleList(i,:)];
                    end
                end
                
                if isempty(vehicleIDList)==0
                    for i=1:4
                        vehicleArmList=VehicleListArm{i};
                        if isempty(vehicleArmList)==0
                            vehicleArmListNum=length(vehicleArmList(:,1));
                            agents=[];
                            targets=[];
                            for j=1:vehicleArmListNum
                                agents=[agents;vehicleArmList(j,11),vehicleArmList(j,9)+1];
                                targets=[targets;vehicleArmList(j,12),vehicleArmList(j,13)+1];
                            end
                            %                         figure(i)
                            %                         clf
                            
                            i;
                            agents;
                            targets;
                            [paths,answer]=CBS(agents,targets);
                            if answer{6}==-1
                                break
                            end
                            
                            pathRelative=answer{1};
                            coordinates=agents;
                            
                            pathsTemp=pathRelative{1,1};
                            paths=length(pathsTemp(:,1));
                            coordinateMap=zeros(vehicleArmListNum,paths*2);
                            for ii=1:paths
                                for j=1:vehicleArmListNum
                                    
                                    placeTemp=pathRelative{j,1};
                                    coordinateMap(j,ii*2-1)=placeTemp(ii,1);
                                    coordinateMap(j,ii*2)=placeTemp(ii,2);
                                    
                                end
                                
                            end
                            coordinateMap;
                            
                            for ii=1:vehicleArmListNum
                                a=pathRelative{ii};
                                pathTemp=[];
                                for j=1:paths-1
                                    pathTemp=[pathTemp;coordinateMap(ii,j*2+1)-coordinateMap(ii,j*2-1),coordinateMap(ii,j*2+2)-coordinateMap(ii,j*2)];
                                end
                                ii;
                                pathTemp;
                                pathRelative{ii}=pathTemp;
                                %     pathTemp
                            end
                            % pathRelative
                            coordinateMap;
                            % pause(2)
                            
                            %%
                            
                            
                            akSeries=cell(vehicleArmListNum,1);
                            vkSeries=cell(vehicleArmListNum,1);
                            timeSeries=cell(vehicleArmListNum,1);
                            akRealSeries=cell(vehicleArmListNum,1);
                            vkRealSeries=cell(vehicleArmListNum,1);
                            
                            totalPointListSet=cell(vehicleArmListNum,1);
                            Goals=[];
                            
                            control_count=0;
                            control_pick=0;
                            closestPosition=ones(vehicleArmListNum,1);
                            
                            vehicleSpeedListTemp=[];
                            vehicleChangeLaneListTemp=[];
                            
                            for ii=1:vehicleArmListNum
                                pathRelativeI=pathRelative{ii};
                                
                                pathLengthI=length(pathRelativeI(:,1));
                                
                                
                                vehicleArmList(ii,14)=pathRelativeI(1);
                                vehicleArmList(ii,15)=pathRelativeI(2);
                                
                                vehicleArmList(ii,20)=0;
                                vehicleArmList(ii,21)=0;
                                vehicleArmList(ii,22)=0;
                                
                                for iii=1:pathLengthI
                                    if pathRelativeI(iii,1)==1
                                        vehicleArmList(ii,20)=vehicleArmList(ii,20)+1;
                                    end
                                    if pathRelativeI(iii,1)==-1
                                        vehicleArmList(ii,21)=vehicleArmList(ii,21)+1;
                                    end
                                    if pathRelativeI(iii,2)~=0
                                        vehicleArmList(ii,22)=vehicleArmList(ii,22)+1;
                                    end
                                end
                                
                                pathRelativeI=pathRelativeI(1,:);
                                
                                for ji=1:length(vehicleList1(:,1))
                                    if vehicleList1(ji,1)==vehicleArmList(ii,1)
                                        vehicleList1(ji,14)=vehicleArmList(ii,14);
                                        vehicleList1(ji,15)=vehicleArmList(ii,15);
                                    end
                                end
                                
                                vehicleInfo=zeros(1,4);
                                vehicleInfo(1)=-vehicleArmList(ii,6);
                                vehicleInfo(2)=vehicleArmList(ii,9)*laneWidth;
                                vehicleInfo(3)=90;
                                vehicleInfo(4)=vehicleArmList(ii,5);
                                
                                [solutionI,totalPointList,goals] = singleVehicleCalculate(pathRelativeI,vF,T,gap,[vehicleInfo 0 0],-MiniInterDistance,coordinates(ii,:));
                                Goals=[Goals;goals];
                                totalPointListSet{ii,1}=totalPointList;
                                phaseTimes=length(pathRelativeI(:,1));
                                akSeries{ii,1}=solutionI.phase(1).control;
                                vkSeries{ii,1}=solutionI.phase(1).state(:,2);
                                
                                timeSeries{ii,1}=solutionI.phase(1).time;
                                for j=2:phaseTimes
                                    akSeries{ii,1}=[akSeries{ii,1};solutionI.phase(j).control];
                                    vkSeries{ii,1}=[vkSeries{ii,1};solutionI.phase(j).state(:,2)];
                                    timeSeries{ii,1}=[timeSeries{ii,1};solutionI.phase(j).time];
                                end
                                
                                akTemp=akSeries{ii,1};
                                vkTemp=vkSeries{ii,1};
                                timeTemp=timeSeries{ii,1};
                                akRealTemp=[];
                                vkRealTemp=vkTemp(1);
                                
                                for j=dt:dt:phaseTimes*T
                                    for k=1:length(vkSeries{ii,1})-1
                                        if timeTemp(k+1)>=j
                                            akRealTemp=[akRealTemp;akTemp(k)+(akTemp(k+1)-akTemp(k))*(j-timeTemp(k))/(timeTemp(k+1)-timeTemp(k)+0.00001)];
                                            vkRealTemp=[vkRealTemp;vkTemp(k)+(vkTemp(k+1)-vkTemp(k))*(j-timeTemp(k))/(timeTemp(k+1)-timeTemp(k)+0.00001)];
                                            break
                                        end
                                    end
                                end
                                
                                akRealSeries{ii,1}=akRealTemp;
                                vkRealSeries{ii,1}=vkRealTemp;
                                
                                vehicleSpeedListTemp=[vehicleSpeedListTemp;vkRealTemp(1:T/dt)'];
                                vehicleChangeLaneListTemp=[vehicleChangeLaneListTemp;pathRelativeI(1,2),pathRelativeI(1,2)+vehicleArmList(ii,9)];
                                
                            end
                            
                            vehicleSpeedList{i}=vehicleSpeedListTemp;
                            vehicleChangeLaneList{i}=vehicleChangeLaneListTemp;
                            
                            controlFirstStep=step;
                            
                            
                        end
                        VehicleListArm{i}=vehicleArmList;
                    end
                end
                if answer{6}==-1
                    break
                end
            end
            if answer{6}==-1
                break
            end
            
            
            TT=1;
            if floor((step+1)/TT)~=floor(step/TT) || step==1
                
                
                if isempty(vehicleIDList)==0
                    
                    
                    
                    
                    for iii=1:4
                        vehicleArmList=VehicleListArm{iii};
                        
                        if isempty(vehicleArmList)==0
                            vehicleArmListNum=length(vehicleArmList(:,1));
                            if isempty(vehicleSpeedList)==1
                                for i=1:vehicleArmListNum
                                    vehicleID=num2str(vehicleArmList(i,1));
                                    traci.vehicle.setSpeed(vehicleID,vF);
                                    vehLaneIndex=traci.vehicle.getLaneIndex(vehicleID);
                                    traci.vehicle.changeLane(vehicleID,vehLaneIndex,2);
                                end
                            else
                                speedListTemp=vehicleSpeedList{iii};
                                changeLaneListTemp=vehicleChangeLaneList{iii};
                                if step==controlFirstStep
                                    vehicleArmListNum=length(vehicleArmList(:,1));
                                    vehiclesGoalChangeLane=zeros(vehicleArmListNum,1);
                                end
                                
                                vehicleArmListNum=length(vehicleArmList(:,1));
                                for i=1:vehicleArmListNum
                                    
                                    vehicleID=num2str(vehicleArmList(i,1));
                                    goalSpeed=speedListTemp(i,step-controlFirstStep+1);
                                    traci.vehicle.setSpeed(vehicleID,goalSpeed);
                                    
                                    if layerModeNum==1
                                        boundTemp=15;
                                    elseif layerModeNum==2
                                        boundTemp=15;
                                    end
                                    
%                                     if vehicleArmList(i,1)==1591
%                                         testTemp=[testTemp;vehicleArmList(i,1),vehicleArmList(i,20),vehicleArmList(i,21),vehicleArmList(i,22),(vehicleArmList(i,20)*(vF*T-gap)+vehicleArmList(i,21)*(vF*T+gap)+vehicleArmList(i,22)*(vF*T)),vehicleArmList(i,6)-boundTemp];
%                                         testTemp
%                                     end
                                    
                                    if vehicleArmList(i,11)<vehicleArmList(i,12) && (vehicleArmList(i,20)*(vF*T-gap+1)+vehicleArmList(i,21)*(vF*T+gap+1)+vehicleArmList(i,22)*(vF*T+1))>vehicleArmList(i,6)-boundTemp
                                        disp(['have to stop, ID: ',num2str(vehicleArmList(i,1))])
                                        traci.vehicle.setSpeed(vehicleID,0);
                                    end
                                    
                                    
                                    vehLaneIndex=traci.vehicle.getLaneIndex(vehicleID);
                                    goalChangeLane=changeLaneListTemp(i,1);
                                    goalLane=changeLaneListTemp(i,2);
                                    
                                    if vehLaneIndex==goalLane
                                        vehiclesGoalChangeLane(i)=vehLaneIndex;
                                    else
                                        vehiclesGoalChangeLane(i)=vehLaneIndex+goalChangeLane;
                                    end
                                    
                                    vehRoadID = traci.vehicle.getRoadID(vehicleID);
                                    if vehRoadID(length(vehRoadID))=='n'
                                        
                                        traci.vehicle.changeLane(vehicleID,vehiclesGoalChangeLane(i),2);
                                        
                                    end
                                    
                                    
                                end
                            end
                            
                            
                            
                        end
                    end
                    
                    
                    for iii=1:vehicleIDListNum
                        vehicleID=num2str(vehicleList(iii,1));
                        Temp = traci.vehicle.getPosition(vehicleID);
                        xTemp=Temp(1);
                        yTemp=Temp(2);
                        
                        if Load_length-15<xTemp && xTemp<Load_length+15 && Load_length-15<yTemp && yTemp<Load_length+15
                            deleteSet=[deleteSet,vehicleList(iii,1)];
                            
                            traci.vehicle.setSpeedMode(vehicleID,0);%7
                            traci.vehicle.setSpeed(vehicleID,vF);%7
                            traci.vehicle.setLaneChangeMode(vehicleID,512);
                        end
                    end
                    
                    
                end
            end
            
            
            if vehicleGenerateCount>0 && isempty(vehicleIDList)==1 && step>T*10*3
                vehicleIDList
                break
            end
            
            %%
            %��ͼ����
            %             vehicleGroupsLayer;
            %             pause(0.01)
            %
            
            if drawFigure==1
                TT=T*10;
                if floor((step+1)/TT)~=floor(step/TT) || step==1
                    figure(2)
                    clf
                    hold on
                    plot([-50,-2],[0,0],'Color','k','LineWidth',1)
                    plot([-50,-2],[-1,-1],'Color','k','LineWidth',1)
                    plot([-50,-2],[-2,-2],'Color','k','LineWidth',1)
                    plot([50,2],[0,0],'Color','k','LineWidth',1)
                    plot([50,2],[1,1],'Color','k','LineWidth',1)
                    plot([50,2],[2,2],'Color','k','LineWidth',1)
                    plot([0,0],[50,2],'Color','k','LineWidth',1)
                    plot([-1,-1],[50,2],'Color','k','LineWidth',1)
                    plot([-2,-2],[50,2],'Color','k','LineWidth',1)
                    plot([0,0],[-50,-2],'Color','k','LineWidth',1)
                    plot([1,1],[-50,-2],'Color','k','LineWidth',1)
                    plot([2,2],[-50,-2],'Color','k','LineWidth',1)
                    if isempty(vehicleIDList)==0
                        for ii=1:vehicleIDListNum
                            vehicleLane=vehicleList(ii,9);
                            goalLane=vehicleList(ii,13);
                            vehicleLayer=vehicleList(ii,11)+1;
                            goalLayer=vehicleList(ii,12)+1;
                            vehicleDir=vehicleList(ii,7);
                            switch vehicleDir
                                case 0
                                    x=vehicleLane-2;
                                    y=vehicleLayer;
                                    x2=goalLane-2;
                                    y2=goalLayer;
                                case 1
                                    x=vehicleLayer;
                                    y=-vehicleLane+2;
                                    x2=goalLayer;
                                    y2=-goalLane+2;
                                case 2
                                    x=-vehicleLane+2;
                                    y=-vehicleLayer;
                                    x2=-goalLane+2;
                                    y2=-goalLayer;
                                case 3
                                    x=-vehicleLayer;
                                    y=vehicleLane-2;
                                    x2=-goalLayer;
                                    y2=goalLane-2;
                            end
                            switch vehicleList(ii,10)
                                case 0
                                    vehicleColor='r';
                                case 1
                                    vehicleColor='g';
                                case 2
                                    vehicleColor='b';
                            end
                            scatter(x,y,40,'MarkerFaceColor',vehicleColor,'MarkerEdgeColor','k')
                            scatter(x2,y2,60,'MarkerEdgeColor',vehicleColor)
                            plot([x,x2],[y,y2],'Color','m','LineWidth',3)
                            
                            
                            
                        end
                    end
                    
                    axis equal
                    axis([-25 25 -25 25])
                    grid minor
                    pause(0.01)
                    
                    f=getframe(gcf);
                    str0=['resultTest\'];
                    str1=num2str(step);
                    str2=['.jpg'];
                    save_path=[str0,str1,str2];
                    print('-dpng','-r300',save_path);
                end
            end

            
            
            vehicleListNew=[];
            vehicleIDListTemp = traci.vehicle.getIDList();
            vehicleIDList={};
            if isempty(vehicleIDListTemp)==0
                for i=1:length(vehicleIDListTemp)
                    vehicleIDList=[vehicleIDList,vehicleIDListTemp{i}];
                end
            end
            if isempty(vehicleIDList)==0
                vehicleIDListNum=length(vehicleIDList);
                vehicleListNew=zeros(vehicleIDListNum,25);
                
                for i=1:vehicleIDListNum
                    vehicleListNew(i,1)=str2double(vehicleIDList{i});
                    Vehicle_ID=vehicleIDList{i};
                    Temp = traci.vehicle.getPosition(Vehicle_ID);
                    vehicleListNew(i,2)=Temp(1);
                    vehicleListNew(i,3)=Temp(2);
                    vehicleListNew(i,4)=traci.vehicle.getAngle(Vehicle_ID);
                    vehicleListNew(i,5)=traci.vehicle.getSpeed(Vehicle_ID);
                    vehicleListNew(i,6)=max(abs(Load_length-Temp(1)),abs(Load_length-Temp(2)));
                    vehRoute = traci.vehicle.getRoute(Vehicle_ID);
                    fromDir=vehRoute{1};
                    toDir=vehRoute{2};
                    switch fromDir(1)
                        case 'N'
                            vehicleListNew(i,7)=0;
                        case 'E'
                            vehicleListNew(i,7)=1;
                        case 'S'
                            vehicleListNew(i,7)=2;
                        case 'W'
                            vehicleListNew(i,7)=3;
                    end
                    switch toDir(1)
                        case 'N'
                            vehicleListNew(i,8)=0;
                        case 'E'
                            vehicleListNew(i,8)=1;
                        case 'S'
                            vehicleListNew(i,8)=2;
                        case 'W'
                            vehicleListNew(i,8)=3;
                    end
                    
                    vehicleListNew(i,9) = traci.vehicle.getLaneIndex(Vehicle_ID);
                    vehTypeID = traci.vehicle.getTypeID(Vehicle_ID);
                    switch vehTypeID(5)
                        case 'L'
                            vehicleListNew(i,10)=2;
                        case 'F'
                            vehicleListNew(i,10)=1;
                        case 'R'
                            vehicleListNew(i,10)=0;
                    end
                    vehicleListNew;%1ID,2x,3y,4angle,5speed,6distance,7from,8to,9self lane,10turn,11self layer,12goal layer,13goal lane
                    
                    
                    
                end
                
                vehicleListNew=sortrows(vehicleListNew,1);
            end
            
            vehicleState=[vehicleState,{vehicleListNew}];
            
            %
            
            
            
            
            
            %             pause(0.1)
        end
        if answer{6}==-1
            save([num2str(layerModeNum),'_Result_',num2str(suijishu),'_',num2str(liuliang),'_',num2str(bili),'(Error).mat'],'vehicleState')
        elseif timeOut==1
            save([num2str(layerModeNum),'_Result_',num2str(suijishu),'_',num2str(liuliang),'_',num2str(bili),'(TimeOut).mat'],'vehicleState')
        else
            save([num2str(layerModeNum),'_Result_',num2str(suijishu),'_',num2str(liuliang),'_',num2str(bili),'.mat'],'vehicleState')
        end
        
        
        traci.close()
        
        
        
    end
end
