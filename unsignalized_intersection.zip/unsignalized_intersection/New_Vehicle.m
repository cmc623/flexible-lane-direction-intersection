function New_Vehicle()
    load('Parameter.mat','routePath','Depart_Gap','Scenario_Type','Total_Simulation_Vehicle','Penetration_Rate','RegularPlatoonSize');
%% Headings
    delete(routePath);
    fid=fopen(routePath,'w+');
    fprintf(fid,'%s\r\n','<routes>');
    fprintf(fid,'%s\r\n','        <vType id="CAV_L" accel="30" decel="30" emergencyDecel="30" tau="0.1" length="4" minGap="1" delta="4" stepping="0.1" carFollowModel="IDM" guiShape="passenger" lcStrategic="0" lcSpeedGain ="0" lcKeepRight="0" color="0,0,255"/>');
    fprintf(fid,'%s\r\n','        <vType id="CAV_F" accel="30" decel="30" emergencyDecel="30" tau="0.1" length="4" minGap="1" delta="4" stepping="0.1" carFollowModel="IDM" guiShape="passenger" lcStrategic="0" lcSpeedGain ="0" lcKeepRight="0" color="0,255,0"/>');
    fprintf(fid,'%s\r\n','        <vType id="CAV_R" accel="30" decel="30" emergencyDecel="30" tau="0.1" length="4" minGap="1" delta="4" stepping="0.1" carFollowModel="IDM" guiShape="passenger" lcStrategic="0" lcSpeedGain ="0" lcKeepRight="0" color="255,0,0"/>');
   
    fprintf(fid,'%s\r\n','        <route id="West_in_East_out" edges="West_in East_out"/>');
    fprintf(fid,'%s\r\n','        <route id="West_in_North_out" edges="West_in North_out"/>');
    fprintf(fid,'%s\r\n','        <route id="West_in_South_out" edges="West_in South_out"/>');
    
    fprintf(fid,'%s\r\n','        <route id="East_in_West_out" edges="East_in West_out"/>');
    fprintf(fid,'%s\r\n','        <route id="East_in_North_out" edges="East_in North_out"/>');
    fprintf(fid,'%s\r\n','        <route id="East_in_South_out" edges="East_in South_out"/>');
    
    fprintf(fid,'%s\r\n','        <route id="South_in_East_out" edges="South_in East_out"/>');
    fprintf(fid,'%s\r\n','        <route id="South_in_North_out" edges="South_in North_out"/>');
    fprintf(fid,'%s\r\n','        <route id="South_in_West_out" edges="South_in West_out"/>');
    
    fprintf(fid,'%s\r\n','        <route id="North_in_East_out" edges="North_in East_out"/>');
    fprintf(fid,'%s\r\n','        <route id="North_in_West_out" edges="North_in West_out"/>');
    fprintf(fid,'%s\r\n','        <route id="North_in_South_out" edges="North_in South_out"/>');
    
    
%     fprintf(fid,'%s%d%s\r\n','    <vehicle id="W_R_1" type="CAV" route="West_in_East_out" departLane="1" depart="',0,'"/>');
%     fprintf(fid,'%s%d%s\r\n','    <vehicle id="E_R_1" type="CAV" route="East_in_West_out" departLane="1" depart="',0,'"/>');
%     fprintf(fid,'%s%d%s\r\n','    <vehicle id="S_R_1" type="CAV" route="South_in_North_out" departLane="1" depart="',0,'"/>');
%     fprintf(fid,'%s%d%s\r\n','    <vehicle id="N_R_1" type="CAV" route="North_in_South_out" departLane="1" depart="',0,'"/>');
%     fprintf(fid,'%s%d%s\r\n','    <vehicle id="W_L_1" type="CAV" route="West_in_left_North_out" departLane="2" depart="',0,'"/>');
%     fprintf(fid,'%s%d%s\r\n','    <vehicle id="E_L_1" type="CAV" route="East_in_left_South_out" departLane="2" depart="',0,'"/>');
%     fprintf(fid,'%s%d%s\r\n','    <vehicle id="S_L_1" type="CAV" route="South_in_left_West_out" departLane="2" depart="',0,'"/>');
%     fprintf(fid,'%s%d%s\r\n','    <vehicle id="N_L_1" type="CAV" route="North_in_left_East_out" departLane="2" depart="',0,'"/>');


    fprintf(fid,'%s\r\n','</routes>');
    fclose(fid);
end
